-- FPV shell appearance. Runs only on the existing game-thread menu poll.
local M={delay=1.5}
local Copy=require("menu-copy")
local function color(hex,a)
 local t={A=a or 1};local i=1
 for _,k in ipairs({"R","G","B"}) do local n=tonumber(hex:sub(i,i+1),16)/255;t[k]=n<=.04045 and n/12.92 or ((n+.055)/1.055)^2.4;i=i+2 end
 return t
end
function M.mix(a,b,t) local c={} for _,k in ipairs({"R","G","B","A"}) do c[k]=(a[k] or 1)+((b[k] or 1)-(a[k] or 1))*t end return c end
local function palette(bg,edge,accent,second,button,active)
 local p={panelBg=color(bg),panelBorder=color(edge),textPrimary=color("E7ECEB"),textMuted=color("99A8AC"),textAccent=color(accent),textStatus=color("AEBDBB"),buttonBg=color(button),buttonBgActive=color(active),buttonBgPrimary=color(active),sectionHeaderBg=color(button),fieldBg=color(bg),dropdownHeaderBg=color(button),dropdownOptionBg=color(bg),confirmCardBg=color(bg),confirmDivider=color(edge),overlayDim=color("000000",.8),second=color(second)}
 for _,k in ipairs({"buttonText","buttonTextActive","buttonTextPrimary","buttonTextSecondary","dropdownHeaderText","dropdownOptionText","fieldText"}) do p[k]=p.textPrimary end
 p.sectionMark=p.textAccent;p.fieldHint=p.textMuted;p.dropdownMore=p.textMuted;p.buttonBgSecondary=p.buttonBg
 p.buttonBgDisabled=color("252A30");p.buttonTextDisabled=color("758187")
 p.buttonBgDanger=color("522C32");p.buttonTextDanger=color("FFC1BF")
 return p
end
M.palettes={tactical=palette("141A1D","6D603C","FFC366","8DBD83","242D30","63502B"),cyberpunk=palette("101022","4B407C","4DE5F4","B880FF","23213C","30485E")}
local mode="tactical"
local file
local U,Input,Util,UE
local function deps()
 U=U or require("ModMenu.core.umg");Input=Input or require("ModMenu.core.input");Util=Util or require("ModMenu.core.util");UE=UE or require("UEHelpers.UEHelpers")
end
function M.setup(root)
 print("[FPV UI] v.1.0 (release): unified pages and fixed visual defaults.")
 file=root.."/data/menu-theme.txt"
 local f=io.open(file,"r");if f then local s=f:read("*a"):match("^%s*(%w+)");f:close();if M.palettes[s] then mode=s end end
 return M.palettes[mode]
end
function M.mode()return mode end
function M.choose(name)
 assert(M.palettes[name]);mode=name
 if file then local f=io.open(file,"w");if f then f:write(name);f:close() end end
 return M.palettes[name]
end
local function safe(fn)
 local ok,e=pcall(fn)
 if not ok then M.errors=M.errors or {};local s=tostring(e);if not M.errors[s] then M.errors[s]=true;print("[FPV UI] appearance fallback: "..s) end end
end
-- Scalar writes into existing native brushes; never marshal a full FButtonStyle.
-- ESlateBrushDrawType::RoundedBox=4 (UE 5.6); fixed-radius rounding=0.
local function brush(b,r)
 b.DrawAs=4;b.OutlineSettings.RoundingType=0
 b.OutlineSettings.CornerRadii.X=r;b.OutlineSettings.CornerRadii.Y=r
 b.OutlineSettings.CornerRadii.Z=r;b.OutlineSettings.CornerRadii.W=r
 b.OutlineSettings.Width=0
 b.TintColor.SpecifiedColor.R=1;b.TintColor.SpecifiedColor.G=1;b.TintColor.SpecifiedColor.B=1;b.TintColor.SpecifiedColor.A=1
end
function M.button(widget)
 safe(function() for _,k in ipairs({"Normal","Hovered","Pressed","Disabled"}) do brush(widget.WidgetStyle[k],mode=="cyberpunk" and 8 or 5) end end)
end
local function rounded(widget,r) safe(function()brush(widget.Background,r)end) end
local function text(parent,name,str,size,c)
 local w=U.Construct("/Script/UMG.TextBlock",parent,name);U.StyleText(w,size,c);U.SetLabelText(w,str);U.EnableAutoWrap(w);return w
end
local function rect(canvas,name,c,x,y,w,h,relative)
 local b=U.Construct("/Script/UMG.Border",canvas,name);b:SetBrushColor(c);b:SetVisibility(4)
 local s=canvas:AddChildToCanvas(b)
 if relative then s:SetAnchors({Minimum={X=x,Y=y},Maximum={X=x+w,Y=y+h}});s:SetOffsets({Left=0,Top=0,Right=0,Bottom=0})
 else s:SetPosition({X=x,Y=y});s:SetSize({X=w,Y=h}) end
 return b
end
local function auto(slot)
 slot:SetSize({SizeRule=0,Value=0});slot:SetHorizontalAlignment(0);slot:SetVerticalAlignment(1)
 return slot
end
local function toolIcon(host,action,suffix,c,top)
 -- A sibling overlay shares the button's exact rectangle. Button style,
 -- content padding, font bearings and pressed offsets cannot move this icon.
 local canvas=U.Construct("/Script/UMG.CanvasPanel",host,"FPV_Icon_"..action..suffix)
 canvas:SetVisibility(4)
 local slot=host:AddChildToCanvas(canvas)
 slot:SetAnchors({Minimum={X=1,Y=0},Maximum={X=1,Y=0}})
 slot:SetOffsets({Left=-28,Top=top,Right=28,Bottom=26});slot:SetZOrder(1)
 local n=0
 local function bar(x,y,w,h)
  n=n+1
  local part=rect(canvas,"FPV_IconPart_"..action..suffix.."_"..n,c,0,0,w,h,false)
  part.Slot:SetAnchors({Minimum={X=.5,Y=.5},Maximum={X=.5,Y=.5}})
  part.Slot:SetOffsets({Left=x,Top=y,Right=w,Bottom=h})
 end
 if action=="close" then
  for k=-4,4 do bar(k-1,k-1,2,2);if k~=0 then bar(k-1,-k-1,2,2) end end
 elseif action=="theme" then bar(-5,-6,10,2);bar(-1,-4,2,10)
 else bar(-1,-6,2,2);bar(-1,-2,2,8) end
 return canvas
end
function M.layout(S,fill,scroll,suffix)
 deps()
 -- Allocate chrome independently of desired text sizes and ScrollBox layout.
 local layout=U.Construct("/Script/UMG.CanvasPanel",fill,"FPV_Layout_"..suffix);fill:SetContent(layout)
 local fillSlot=layout.Slot;fillSlot:SetHorizontalAlignment(0);fillSlot:SetVerticalAlignment(0)
 S.headerBox=U.Construct("/Script/UMG.CanvasPanel",layout,"FPV_HeaderHost_"..suffix)
 local hs=layout:AddChildToCanvas(S.headerBox);hs:SetAnchors({Minimum={X=0,Y=0},Maximum={X=1,Y=0}});hs:SetOffsets({Left=0,Top=0,Right=0,Bottom=104})
 S.navSize=U.Construct("/Script/UMG.SizeBox",layout,"FPV_NavSize_"..suffix)
 local ns=layout:AddChildToCanvas(S.navSize);ns:SetAnchors({Minimum={X=0,Y=0},Maximum={X=1,Y=0}});ns:SetOffsets({Left=0,Top=104,Right=0,Bottom=78})
 S.navBox=U.Construct("/Script/UMG.VerticalBox",S.navSize,"FPV_Nav_"..suffix);S.navSize:SetContent(S.navBox)
 S.navBox.Slot:SetHorizontalAlignment(0);S.navBox.Slot:SetVerticalAlignment(1)
 S.bodySlot=layout:AddChildToCanvas(scroll);S.bodySlot:SetAnchors({Minimum={X=0,Y=0},Maximum={X=1,Y=1}});S.bodySlot:SetOffsets({Left=0,Top=182,Right=0,Bottom=0})
 -- Explicit top alignment: a short rebuilt page must not be centred in the scroll viewport.
 local content=U.Construct("/Script/UMG.VerticalBox",scroll,"FPV_Body_"..suffix)
 local body=scroll:AddChild(content);body:SetHorizontalAlignment(0);body:SetVerticalAlignment(1);body:SetPadding({Left=0,Top=0,Right=8,Bottom=0})
 safe(function()scroll.FrontPadScrolling=false;scroll.BackPadScrolling=false end)
 scroll:SetAllowOverscroll(false);scroll:SetScrollOffset(0)
 return content
end
function M.navigation(S)
 S.navSize:SetVisibility(S.designInfo and 1 or 0)
 S.bodySlot:SetOffsets({Left=0,Top=S.designInfo and 104 or 182,Right=0,Bottom=0})
end
function M.startTransition(S)
 S.designTransition=true;S.designTransitionStart=nil;M.clearTip(S)
 if S.menuScroll then S.menuScroll:SetScrollOffset(0) end
end
function M.toggle(ctrl,ctx)
 deps();local row=U.Construct("/Script/UMG.HorizontalBox",ctrl.widget,ctx.namePrefix.."_ToggleRow")
 local s=row:AddChildToHorizontalBox(ctrl.label);s:SetSize({SizeRule=1,Value=1});s:SetVerticalAlignment(2);s:SetHorizontalAlignment(0)
 ctrl.label:SetJustification(0)
 local badge=U.Construct("/Script/UMG.SizeBox",row,ctx.namePrefix.."_BadgeSize");badge:SetWidthOverride(48)
 local state=text(badge,ctx.namePrefix.."_State","",11,M.palettes[mode].textMuted);state:SetJustification(2);badge:SetContent(state)
 local bs=row:AddChildToHorizontalBox(badge);bs:SetSize({SizeRule=0,Value=0});bs:SetVerticalAlignment(2)
 ctrl.widget:SetContent(row);row.Slot:SetPadding({Left=12,Top=7,Right=12,Bottom=7})
 ctrl.designStateLabel=state
end
function M.slider(ctx,box,widget)
 deps();local p=M.palettes[mode]
 local overlay=U.Construct("/Script/UMG.Overlay",box,ctx.namePrefix.."_Layers")
 box:AddChild(overlay)
 local canvas=U.Construct("/Script/UMG.CanvasPanel",overlay,ctx.namePrefix.."_Gradient")
 local slot=overlay:AddChildToOverlay(canvas);slot:SetHorizontalAlignment(0);slot:SetVerticalAlignment(0);canvas:SetVisibility(4)
 local n=mode=="cyberpunk" and 48 or 1
 for i=0,n-1 do
  local b=rect(canvas,ctx.namePrefix.."_Band"..i,M.mix(p.textAccent,p.second,n==1 and 0 or i/(n-1)),i/n,.5,1/n,0,true)
  local s=b.Slot;s:SetOffsets({Left=0,Top=-2,Right=0,Bottom=4})
 end
 local s=overlay:AddChildToOverlay(widget);s:SetHorizontalAlignment(0);s:SetVerticalAlignment(0)
 widget:SetSliderBarColor({R=0,G=0,B=0,A=0});widget:SetSliderHandleColor(p.textAccent)
end
function M.clearTip(S)
 S.hoverTarget=nil;S.hoverSince=nil
 if S.tipRoot and S.tipRoot:IsValid() then S.tipRoot:SetVisibility(1) end
end
function M.destroy(S)
 M.clearTip(S);S.tipRoot=nil;S.tipSlot=nil;S.tipText=nil;S.tipBody=nil;S.headerBox=nil;S.designPending=nil;S.designStatus=nil;S.designClock=nil;S.navBox=nil;S.navSize=nil;S.bodySlot=nil;S.designStatusText=nil;S.designTransition=nil
end
function M.hover(state,target,now)
 if target~=state.hoverTarget or (state.hoverSince and now<state.hoverSince) then state.hoverTarget=target;state.hoverSince=target and now or nil end
 return target~=nil and state.hoverSince~=nil and now-state.hoverSince>=M.delay
end
local function timeNow(S)
 local ok,n=pcall(function()return UE.GetGameplayStatics():GetRealTimeSeconds(UE.GetWorld())end)
 if ok and type(n)=="number" then return n end
 -- Fallback to poll duration if no world is available; no per-tooltip timers/callbacks.
 S.designClock=(S.designClock or 0)+.016;return S.designClock
end
function M.header(S,host,suffix)
 deps();M.clearTip(S);host:ClearChildren();local p=M.palettes[mode]
 S.designStatusText=nil
 local left=U.Construct("/Script/UMG.VerticalBox",host,"FPV_Identity_"..suffix)
 local ls=host:AddChildToCanvas(left);ls:SetAnchors({Minimum={X=0,Y=0},Maximum={X=1,Y=1}});ls:SetOffsets({Left=0,Top=2,Right=44,Bottom=0})
 local btn,label=U.CreateTextButton(left,"FPV_Drag_"..suffix,"FPV MENU",{R=0,G=0,B=0,A=0},p.textPrimary,S.config.fontTitle)
 -- Centre the combined identity: the title moves left by half the attribution
 -- width, while the small byline follows it on the same line.
 local identity=U.Construct("/Script/UMG.HorizontalBox",btn,"FPV_IdentityRow_"..suffix)
 label:SetJustification(0);label:SetAutoWrapText(false)
 local titleSlot=identity:AddChildToHorizontalBox(label);titleSlot:SetSize({SizeRule=0,Value=0});titleSlot:SetVerticalAlignment(3)
 local author=text(identity,"FPV_Author_"..suffix,"by sanitar4ick",9,p.textMuted)
 author:SetJustification(0);author:SetAutoWrapText(false)
 local authorSlot=identity:AddChildToHorizontalBox(author);authorSlot:SetSize({SizeRule=0,Value=0});authorSlot:SetVerticalAlignment(3);authorSlot:SetPadding({Left=8,Top=0,Right=0,Bottom=3})
 btn:SetContent(identity);identity.Slot:SetHorizontalAlignment(2);identity.Slot:SetVerticalAlignment(2);identity.Slot:SetPadding({Left=0,Top=0,Right=0,Bottom=0})
 btn:SetClickMethod(0);auto(left:AddChildToVerticalBox(btn));S.dragHandle=btn
 U.AddSpacer(left,"FPV_IdentityGap_"..suffix,14)
 S.designStatus=text(left,"FPV_Link_"..suffix,"",10,p.textMuted);auto(left:AddChildToVerticalBox(S.designStatus))
 auto(left:AddChildToVerticalBox(text(left,"FPV_Keys_"..suffix,"F6  меню     ·     F9  выключить всё",10,p.textMuted)))
 for i,a in ipairs({{"×","close","Закрыть меню · F6"},{"T","theme",mode=="tactical" and "Переключить на Cyberpunk" or "Переключить на Tactical"},{"i","info","Справка: функции, разделы и горячие клавиши"}}) do
  local b=U.Construct("/Script/UMG.Button",host,"FPV_Tool_"..a[2]..suffix)
  b:SetBackgroundColor(p.buttonBg);b:SetClickMethod(1);M.button(b)
  local sl=host:AddChildToCanvas(b);sl:SetAnchors({Minimum={X=1,Y=0},Maximum={X=1,Y=0}});sl:SetOffsets({Left=-28,Top=(i-1)*30,Right=28,Bottom=26})
  local action=a[2]
  local icon=toolIcon(host,action,suffix,p.textAccent,(i-1)*30)
  S.liveControls[#S.liveControls+1]={kind=action=="close" and "close" or "button",widget=b,icon=icon,enabled=true,wasPressed=false,role=action,item={label=a[1],tooltip=a[3],onClick=function()S.designPending=action end}}
 end
 if S.panelBorder then S.panelBorder:SetBrushColor(p.panelBg);rounded(S.panelBorder,mode=="cyberpunk" and 12 or 8) end
 if S.panelOutline then S.panelOutline:SetBrushColor(p.panelBorder);rounded(S.panelOutline,mode=="cyberpunk" and 13 or 9) end
end
function M.info(S,host,suffix)
 deps();local p=M.palettes[mode]
 local function block(id,title,body)
  host:AddChildToVerticalBox(text(host,"FPV_HelpTitle_"..id..suffix,title,S.config.fontSection,p.textAccent))
  U.AddSpacer(host,"FPV_HelpPad_"..id..suffix,6)
  host:AddChildToVerticalBox(text(host,"FPV_HelpText_"..id..suffix,body,S.config.fontItem,p.textPrimary))
  U.AddSpacer(host,"FPV_HelpGap_"..id..suffix,18)
 end
 block("version","FPV MENU · v.1.0 (release)","by sanitar4ick")
 block("credits","Разработка",Copy.credits)
 block("states","Обозначения",Copy.statusLegend)
 block("intro","СПРАВКА / УПРАВЛЕНИЕ","Нажми i повторно, чтобы вернуться к настройкам. Наведи курсор на функцию на 1,5 секунды — появится её описание.")
 if S.connectionNotice then block("error","Последняя ошибка",S.connectionNotice) end
 block("keys","Горячие клавиши",Copy.keys)
 for i,t in ipairs(Copy.tabs) do block(tostring(i),string.format("%02d  /  %s",i,t[1]),t[2]) end
 block("notes","Особенности работы",Copy.notes)
end
local function tooltip(S,body)
 if not S.tipRoot or not S.tipRoot:IsValid() then
  local size=U.Construct("/Script/UMG.SizeBox",S.menuCanvas,"FPV_TipSize_"..S.contentGen);size:SetWidthOverride(330)
  local edge=U.Construct("/Script/UMG.Border",size,"FPV_TipEdge_"..S.contentGen);edge:SetPadding({Left=1,Top=1,Right=1,Bottom=1});size:SetContent(edge)
  local card=U.Construct("/Script/UMG.Border",edge,"FPV_TipCard_"..S.contentGen);card:SetPadding({Left=14,Top=12,Right=14,Bottom=12});edge:SetContent(card)
  S.tipText=text(card,"FPV_TipText_"..S.contentGen,"",13,M.palettes[mode].textPrimary);card:SetContent(S.tipText)
  S.tipSlot=S.menuCanvas:AddChildToCanvas(size);S.tipSlot:SetAutoSize(true);S.tipSlot:SetZOrder(40)
  S.tipRoot=size;S.tipCard=card;S.tipEdge=edge
 end
 S.tipCard:SetBrushColor(M.palettes[mode].panelBg);S.tipEdge:SetBrushColor(M.palettes[mode].textAccent)
 if S.tipBody~=body then U.SetLabelText(S.tipText,body);S.tipBody=body end
 S.tipRoot:SetVisibility(4)
 local lib=StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary");local pc=UE.GetPlayerController()
 if lib and lib:IsValid() and pc and pc:IsValid() then
  local pos=lib:GetMousePositionOnViewport(pc);local v=lib:GetViewportSize(pc);local scale=lib:GetViewportScale(pc)
  if scale and scale>0 then
   local width,height=v.X/scale,v.Y/scale
   local x=pos.X+18;if x+330>width-8 then x=pos.X-348 end
   local desired=S.tipRoot:GetDesiredSize();local h=math.max(110,desired.Y)
   S.tipSlot:SetPosition({X=math.max(8,math.min(width-338,x)),Y=math.max(8,math.min(height-h-8,pos.Y+18))})
  end
 end
end
function M.poll(S)
 deps();local now=timeNow(S);local dt=math.max(0,math.min(.05,now-(S.designLastTime or now)));S.designLastTime=now
 if S.designTransition then
  S.designTransitionStart=S.designTransitionStart or now
  local t=math.min(1,(now-S.designTransitionStart)/.20);local eased=1-(1-t)^3
  if S.contentBox then S.contentBox:SetRenderOpacity(.45+.55*eased);S.contentBox:SetRenderTranslation({X=0,Y=6*(1-eased)}) end
  if t>=1 then S.designTransition=nil end
 end
 if S.confirm or S.pendingClose or S.designPending or S.dragOrigin then M.clearTip(S);return end
 local target
 for _,c in ipairs(S.liveControls) do
  local hovered=Input.WidgetHovered(c.widget or c.headerBtn) or Input.WidgetHovered(c.label or c.labelWidget or c.headerLabel)
  if hovered and c.item and c.item.tooltip then target=c end
  if c.designStateLabel then
   local on=S.values[c.valueKey]==true
   if c.designOn~=on then c.designOn=on;U.SetLabelText(c.designStateLabel,on and "ВКЛ" or "ВЫКЛ");U.StyleText(c.designStateLabel,11,on and M.palettes[mode].textAccent or M.palettes[mode].textMuted);c.designPainted=false end
  end
  -- No animation callbacks, widget recreation, or gameplay writes.
  if c.kind=="button" or c.kind=="checkbox" and c.asButton or c.kind=="tab" or c.kind=="close" or c.kind=="collapse" then
   local previous=c.designFade or 0;local goal=hovered and 1 or 0
   local fade=previous+(goal-previous)*math.min(1,dt/0.10)
   if math.abs(goal-fade)<.01 then fade=goal end
   if fade~=previous or c.designPainted~=true then
    c.designFade=fade;c.designPainted=true
    local p=M.palettes[mode];local base=p.buttonBg
    if c.kind=="tab" and c.tabId==S.activeTab or c.kind=="checkbox" and S.values[c.valueKey]==true then base=p.buttonBgActive end
    if c.item and c.item.variant=="primary" then base=p.buttonBgPrimary elseif c.item and c.item.variant=="danger" then base=p.buttonBgDanger end
    if c.enabled==false then base=p.buttonBgDisabled;fade=0 end
    if c.widget and c.widget:IsValid() then c.widget:SetBackgroundColor(M.mix(base,p.textAccent,fade*.32)) end
   end
  end
 end
 local show=M.hover(S,target,now)
 if show then tooltip(S,target.item.tooltip);S.tipRoot:SetRenderOpacity(math.min(1,(now-S.hoverSince-M.delay)/.12)) elseif S.tipRoot and S.tipRoot:IsValid() then S.tipRoot:SetVisibility(1) end
 if S.designStatus and S.designStatus:IsValid() then
  local status=S.connectionNotice and "Ошибка настройки · подробнее в справке" or (S.connectionText=="МОДУЛЬ: ПОДКЛЮЧЁН" and "●  Подключено" or "○  Ожидание модуля")
  if S.designStatusText~=status then U.SetLabelText(S.designStatus,status);U.StyleText(S.designStatus,S.config.fontHint,status=="●  Подключено" and color("8DBD83") or M.palettes[mode].textAccent);S.designStatusText=status end
 end
end
function M.flush(S)
 if not S.designPending then return end
 deps();local pc=UE.GetPlayerController()
 if pc and pc:IsValid() and pc:IsInputKeyDown({KeyName=FName("LeftMouseButton")}) then return end
 if not S.designApplyFn then S.designApplyFn=Util.PinFn(function()
  local action=S.designPending;S.designPending=nil;S.designScheduled=false
  if not S.menuOpen or not action then return end
  if action=="theme" then
   local p=M.choose(mode=="tactical" and "cyberpunk" or "tactical")
   S.config.colors=require("ModMenu.core.theme").Resolve("dark",p);U.SetDefaults({fontItem=S.config.fontItem,colors=S.config.colors})
  elseif action=="info" then S.designInfo=not S.designInfo end
  require("ModMenu.shell.build").BuildContent(S)
  if S.menuScroll then S.menuScroll:ScrollToStart() end
  Input.ClearClickState();Input.IgnoreClicks(2)
 end) end
 if not S.designScheduled then S.designScheduled=true;ExecuteInGameThreadWithDelay(1,S.designApplyFn) end
end
return M
