local Menu=require("ModMenu.ModMenu")
local M={}
local Options=require("movement-options")
local Design=require("menu-design")
function M.create(control,actions)
    control.shiftOnly="1"
    Menu.Init({design=true,title="FPV MENU",instanceId="FPVInGame",key=Key.F6,keyHint="F6",
        theme="dark",dock="right",widthFrac=0.30,topFrac=0.12,bottomFrac=0.16,rightFrac=0.035,
        fontTitle=20,fontItem=13,fontHint=10,fontSection=14,fontDropdown=13,showDock=false,ignoreLook=true,
        colors=Design.setup(actions.root),
        inputBackend="ue4ss",cursorMode="engine",tabs={"Weapon","ESP/WH","Движение","Телепорт","Персонаж","Профили"},debug=false})
    require("foenem").attach(Menu,actions.root)
    Menu.Register({id="protection",title="Бессмертие",collapsible=true,collapsed=false,tab="Персонаж",items={
        {type="checkbox",id="enabled",label="Бессмертие",asButton=true,default=false,onChange=function(on) control.immortal=on end},
        {type="label",id="status",label="Выключено. Доступно в собственном лобби."},
    }})
    Menu.Register({id="run",title="Ультрабег",collapsible=true,collapsed=false,tab="Движение",items={
        {type="checkbox",id="enabled",label="Ультрабег · Shift",asButton=true,default=false,onChange=function(on) control.enabled=on and "1" or "0" end},
        {type="slider",id="multiplier",label="Множитель",min=1,max=10,step=0.1,default=2,onChange=function(n) control.multiplier=tostring(n) end},
    }})
    Menu.Register({id="vehicleboost",title="Разгон транспорта",collapsible=true,collapsed=true,tab="Движение",items={
        {type="checkbox",id="enabled",label="Быстрый разгон транспорта",asButton=true,default=false,onChange=function(on) control.vehicleBoost=on end},
        {type="slider",id="power",label="Сила разгона",min=1,max=10,step=.5,default=3,onChange=function(n) control.vehicleMultiplier=n end},
        {type="slider",id="speed",label="Предел помощи, км/ч",min=Options.vehicle.min,max=Options.vehicle.max,step=5,default=Options.vehicle.default,valueFormat="%.0f",onChange=function(n) control.vehicleSpeed=Options.speed("vehicle",n) end},
        {type="label",id="status",label="Выключено. Сядь за руль транспорта."},
    }})
    Menu.Register({id="droneboost",title="Разгон ударного дрона",collapsible=true,collapsed=true,tab="Движение",items={
        {type="checkbox",id="enabled",label="Ускорить ударный дрон",asButton=true,default=false,onChange=function(on) control.droneBoost=on end},
        {type="slider",id="multiplier",label="Сила ускорения",min=1,max=10,step=.5,default=2,onChange=function(n) control.droneMultiplier=n end},
        {type="slider",id="ramp",label="Нарастание усиления, с",min=.2,max=3,step=.05,default=.75,valueFormat="%.2f",onChange=function(n) control.droneRamp=n end},
        {type="slider",id="speed",label="Предел помощи, км/ч",min=Options.drone.min,max=Options.drone.max,step=5,default=Options.drone.default,valueFormat="%.0f",onChange=function(n) control.droneSpeed=Options.speed("drone",n) end},
        {type="slider",id="steering",label="Помощь в поворотах, %",min=0,max=100,step=10,default=50,valueFormat="%.0f",onChange=function(n) control.droneSteering=n end},
        {type="label",id="status",label="Выключено. Переключись на ударный дрон."},
    }})
    Menu.Register({id="drivehud",title="Спидометр и колесо мыши",collapsible=true,collapsed=true,tab="Движение",items={
        {type="checkbox",id="visible",label="Панель скорости",asButton=true,default=true,onChange=function(on) control.driveHud=on end},
        {type="checkbox",id="wheel",label="Колесо меняет предел скорости",asButton=true,default=true,onChange=function(on) control.speedWheel=on end},
    }})
    Menu.Register({id="clickwarp",title="Clickwarp",collapsible=true,collapsed=false,tab="Телепорт",items={
        {type="checkbox",id="enabled",label="Clickwarp",asButton=true,default=false,onChange=function(on) control.clickwarp=on end},
        {type="label",id="status",label="Включи Clickwarp и нажми СКМ / F10."},
        {type="label",id="result",label=""},
    }})
    Menu.Register({id="travel",title="К транспорту",collapsible=true,collapsed=true,tab="Телепорт",items={
        {type="dropdown",id="target",label="Транспорт и расстояние",searchable=true,placeholder="Выбери машину",maxVisible=32,listMaxHeight=180,
            options={{label="Загрузка списка…",value="__none"}},default="__none",onChange=function(id) control.target=id end},
        {type="label",id="distance",label=""},
        {type="button",id="refresh",label="Обновить список",onClick=actions.refresh},
        {type="button",id="selected",label="К выбранному транспорту",variant="primary",onClick=function() actions.teleport(false) end},
        {type="button",id="nearest",label="К ближайшему транспорту",onClick=function() actions.teleport(true) end},
        {type="label",id="result",label=""}
    }})
    require("foenem").bindExtras(control)
    Menu.OnOpen(actions.refresh)
    return Menu
end
return M
