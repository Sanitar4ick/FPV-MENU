local M={};local last,session,pawnAddress,remainder=nil,nil,nil,0
local wasActive=false
function M.read(root,address,active)
    local f=io.open(root.."/data/foenem-state.txt","r");if not f then return {} end
    local data={};for k,v in f:read("*a"):gmatch("([^\r\n=]+)=([^\r\n]*)") do data[k]=v end;f:close()
    local current={wheel=tonumber(data.mouse_wheel),middle=tonumber(data.mouse_middle),left=tonumber(data.mouse_left),escape=tonumber(data.mouse_escape),f10=tonumber(data.clickwarp_f10) or 0}
    if data.bridge~="ready" or not current.wheel or math.abs(os.time()-(tonumber(data.timestamp) or 0))>2 then last=nil;remainder=0;return {} end
    local fresh=session~=data.session or pawnAddress~=address or not last or not wasActive
    local out={}
    if not fresh and active then
        remainder=remainder+current.wheel-last.wheel
        local steps=remainder>=0 and math.floor(remainder/120) or math.ceil(remainder/120)
        remainder=remainder-steps*120;out.wheel=steps
        -- Two toggles in one snapshot cancel each other, just as two separate presses do.
        local middle=math.max(0,current.middle-last.middle)
        local f10=math.max(0,current.f10-last.f10)
        out.middle=(middle+f10)%2==1
        out.source=f10>0 and "F10" or "СКМ"
        out.left=current.left>last.left;out.escape=current.escape>last.escape
    else remainder=0 end
    last=current;session=data.session;pawnAddress=address;wasActive=active
    return out
end
return M
