-- In-game UMG; Foenem settings use the version-locked native adapter without an external window.
local source=debug.getinfo(1,"S").source:sub(2):gsub("\\","/")
local root=assert(source:match("^(.*)/runtime/ue4ss/Mods/FPVInGame/Scripts/main.lua$"))
local controller,pawn,world,movement,kismet,Menu
local tick,pending=0,false
local boost=nil
local vehicle_list={}
local control={enabled="0",multiplier="2.0",shiftOnly="1",target="__none",driveHud=true,speedWheel=true,clickwarp=false}
local VehicleBoost=require("vehicle-boost")
local Options=require("movement-options")
local Mouse=require("mouse-events")
local DriveHUD=require("drive-hud")
local Clickwarp=require("clickwarp")
local TeleportResult=require("teleport-result")
local InactiveESP=require("inactive-esp")
local Protection=require("protection")
local result,mode,message="","waiting","Ожидание игры…"
local action=nil
local teleport_check=nil
local last_pawn=nil

local Helpers=require("UEHelpers.UEHelpers")
Helpers.GetPlayerController=function()
    for _,candidate in ipairs(FindAllOf("PlayerController") or {}) do
        if candidate:IsValid() and candidate:IsLocalPlayerController() then return candidate end
    end
    return CreateInvalidObject()
end

local function valid(obj)
    if obj == nil then return false end
    local ok, value = pcall(function() return obj:IsValid() end)
    return ok and value
end
local function clean(text) return tostring(text):gsub("[\r\n\t]", " ") end
local function vec(v) return {X=v.X, Y=v.Y, Z=v.Z} end
local function distance(a,b)
    return math.sqrt((a.X-b.X)^2+(a.Y-b.Y)^2+(a.Z-b.Z)^2)
end
local function same(a,b) return valid(a) and valid(b) and a:GetAddress()==b:GetAddress() end
local function log(text) print("[FPVHostTools] " .. tostring(text) .. "\n") end

local function restore()
    if boost and valid(boost.object) then
        pcall(function()
            if math.abs(boost.object.MaxWalkSpeed-boost.written_speed)<0.1 then
                boost.object.MaxWalkSpeed=boost.base_speed
            end
            if math.abs(boost.object.MaxAcceleration-boost.written_accel)<0.1 then
                boost.object.MaxAcceleration=boost.base_accel
            end
        end)
    end
    boost=nil
end


local function apply_speed(ready)
    if boost and not same(boost.object,movement) then restore() end
    local should_boost=ready and control.enabled=="1"
    if should_boost and control.shiftOnly~="0" then
        local left=controller:IsInputKeyDown({KeyName=FName("LeftShift")})
        local right=controller:IsInputKeyDown({KeyName=FName("RightShift")})
        should_boost=left or right
    end
    if should_boost then
        local mode=movement.MovementMode
        should_boost=(mode==1 or mode==2 or mode==3) and not pawn.bIsCrouched
    end
    if not should_boost then restore(); return end
    local multiplier=tonumber(control.multiplier) or 1
    if multiplier~=multiplier then multiplier=1 end
    multiplier=math.max(1,math.min(10,multiplier))
    if not boost then
        boost={object=movement,base_speed=movement.MaxWalkSpeed,base_accel=movement.MaxAcceleration}
        boost.written_speed=boost.base_speed; boost.written_accel=boost.base_accel
    else
        if math.abs(movement.MaxWalkSpeed-boost.written_speed)>0.1 then boost.base_speed=movement.MaxWalkSpeed end
        if math.abs(movement.MaxAcceleration-boost.written_accel)>0.1 then boost.base_accel=movement.MaxAcceleration end
    end
    boost.written_speed=boost.base_speed*multiplier
    boost.written_accel=boost.base_accel*multiplier
    movement.MaxWalkSpeed=boost.written_speed
    movement.MaxAcceleration=boost.written_accel
end

local vehicle_names={BP_BMP3_C="БМП-3",BP_UAZ3151_C="УАЗ",BP_QuadBike_C="Квадроцикл",BP_Enduro_C="Мотоцикл"}
local function list_vehicles()
    vehicle_list={}
    if not valid(pawn) or not valid(world) then return end
    local origin=pawn:K2_GetActorLocation()
    for _,actor in ipairs(FindAllOf("BP_Vehicle_Base_C") or {}) do
        if valid(actor) and same(actor:GetWorld(),world) then
            local id=actor:GetFullName()
            local class_name=actor:GetClass():GetFName():ToString()
            local label=vehicle_names[class_name] or class_name:gsub("^BP_",""):gsub("_C$","")
            vehicle_list[#vehicle_list+1]={object=actor,id=id,label=label,distance=distance(origin,actor:K2_GetActorLocation())/100}
        end
    end
    table.sort(vehicle_list,function(a,b) if a.distance==b.distance then return a.id<b.id end return a.distance<b.distance end)
end

local function find_destination(target)
    if not valid(target) or not same(target:GetWorld(),world) then return nil,"Транспорт больше недоступен." end
    if not valid(kismet) then kismet=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary") end
    if not valid(kismet) then return nil,"Система проверки поверхности недоступна." end
    local origin,extent={},{}
    target:GetActorBounds(true,origin,extent,false)
    if not origin.X or not extent.X then return nil,"Не удалось определить размеры транспорта." end
    local capsule=pawn.CapsuleComponent
    if not valid(capsule) then return nil,"Капсула персонажа недоступна." end
    local half_height=capsule:GetScaledCapsuleHalfHeight()
    local radius=capsule:GetScaledCapsuleRadius()
    local clearance=math.max(extent.X,extent.Y)+radius+160
    local current=pawn:K2_GetActorLocation()
    local start_angle=math.atan(current.Y-origin.Y,current.X-origin.X)
    local color={R=0,G=0,B=0,A=0}
    local spots={}
    for _,extra in ipairs({0,200,400}) do
        for i=0,7 do
            local angle=start_angle+i*math.pi/4
            local x=origin.X+math.cos(angle)*(clearance+extra)
            local y=origin.Y+math.sin(angle)*(clearance+extra)
            local hit={}
            local collided=kismet:LineTraceSingle(pawn,
                {X=x,Y=y,Z=origin.Z+extent.Z+500},
                {X=x,Y=y,Z=origin.Z-extent.Z-1800},
                0,false,{pawn,target},0,hit,true,color,color,0)
            if collided and hit.ImpactPoint and hit.ImpactNormal and hit.ImpactNormal.Z>=0.7 then
                spots[#spots+1]={X=hit.ImpactPoint.X,Y=hit.ImpactPoint.Y,Z=hit.ImpactPoint.Z+half_height+5}
            end
        end
    end
    if #spots==0 then return nil,"Рядом с транспортом не найдена подходящая поверхность." end
    return spots,nil
end


local function is_character() return mode=="host" or mode=="client" end
local function context()
    if not valid(controller) or tick%20==1 then controller=Helpers.GetPlayerController() end
    if not valid(controller) then return "waiting","Ожидание локального игрока…" end
    world=controller:GetWorld()
    if not valid(world) then return "waiting","Ожидание карты…" end
    pawn=controller.Pawn
    if not valid(pawn) then return "waiting","Появись пешим персонажем на карте." end
    if not pawn:IsA("/Script/FPVKamikazeDrone.FPVCharacter") then
        return "vehicle","Сейчас выбран дрон или транспорт. Нужен пеший персонаж."
    end
    movement=pawn.CharacterMovement
    if not valid(movement) then return "waiting","Компонент движения недоступен." end
    if not same(pawn:GetWorld(),world) then return "waiting","Смена карты…" end
    if pawn:HasAuthority() then return "host","Подключено • ты хост" end
    return "client","Подключено • ты игрок на сервере"
end

local function refresh_options()
    if not Menu then return end
    list_vehicles()
    local options,selected={},control.target
    local found=false
    for _,entry in ipairs(vehicle_list) do
        options[#options+1]={label=string.format("%s — %.0f м",entry.label,entry.distance),value=entry.id}
        if entry.id==selected then found=true end
    end
    if #options==0 then options={{label="Транспорт пока не найден",value="__none"}};selected="__none"
    elseif not found then selected=options[1].value end
    control.target=selected
    Menu.SetOptions("travel","target",options,selected)
end

local function teleport(nearest)
    if not is_character() then result="Нужен пеший персонаж.";return end
    if teleport_check then result="Проверяется предыдущая телепортация…";return end
    list_vehicles()
    local selected
    if nearest then selected=vehicle_list[1]
    else for _,entry in ipairs(vehicle_list) do if entry.id==control.target then selected=entry;break end end end
    if not selected then result="Машина недоступна. Обнови список.";return end
    local spots,err=find_destination(selected.object)
    if not spots then result=err;return end
    local origin=vec(pawn:K2_GetActorLocation())
    local rotation=pawn:K2_GetActorRotation()
    for _,spot in ipairs(spots) do
        if pawn:K2_TeleportTo(spot,{Pitch=rotation.Pitch,Yaw=rotation.Yaw,Roll=rotation.Roll}) then
            movement:StopMovementImmediately()
            teleport_check={pawn=pawn,world=world,origin=origin,dest=vec(pawn:K2_GetActorLocation()),tick=tick,label=selected.label}
            result="Перемещение выполнено; проверяю, сохранилась ли позиция…"
            log("Teleport local success; mode="..mode.." target="..selected.label)
            return
        end
    end
    result="Рядом с машиной нет свободного места. Перемещение отменено."
end

local function check_teleport()
    if not teleport_check then return end
    local t=teleport_check
    if not same(t.pawn,pawn) or not same(t.world,world) then
        teleport_check=nil;result="Персонаж или карта сменились."
        if t.label=="Clickwarp" then Clickwarp.setStatus(result);Menu.SetLabel("clickwarp","result",result) end
        return
    end
    if tick-t.tick<40 then return end
    local now=vec(pawn:K2_GetActorLocation())
    local verdict,remaining=TeleportResult.assess(t.origin,t.dest,now)
    if verdict=="returned" then
        result="Позиция вернулась к исходной: телепортация на этом сервере не удержалась."
    elseif verdict=="near" then result=string.format("Сейчас рядом с целью: %s (%.1f м).",t.label,remaining/100)
    else result=string.format("После прыжка до точки %.1f м. Сохранение позиции не подтверждено.",remaining/100) end
    log(result.." distance_from_destination="..string.format("%.0f",remaining))
    if t.label=="Clickwarp" then Clickwarp.setStatus(result);Menu.SetLabel("clickwarp","result",result) end
    teleport_check=nil
end

local function update_ui()
    local speed,limit=0,0
    if is_character() then
        local v=pawn:GetVelocity();speed=math.sqrt(v.X*v.X+v.Y*v.Y)/100
        limit=movement:GetMaxSpeed()/100
    end
    Menu.SetLabel("travel","result",result)
    Menu.SetLabel("clickwarp","status",Clickwarp.status())
    Menu.SetLabel("protection","status",Protection.status())
    local vehicleStatus,droneStatus=VehicleBoost.status()
    Menu.SetLabel("vehicleboost","status",vehicleStatus)
    Menu.SetLabel("droneboost","status",droneStatus)
    pcall(VehicleBoost.report,root,controller,pawn,control,Menu.IsOpen())
    Menu.SetButtonEnabled("travel","selected",is_character() and control.target~="__none" and not teleport_check)
    Menu.SetButtonEnabled("travel","nearest",is_character() and #vehicle_list>0 and not teleport_check)
    local selected_distance=""
    for _,entry in ipairs(vehicle_list) do
        if entry.id==control.target then selected_distance=string.format("Выбрано: %s • сейчас %.0f м",entry.label,entry.distance);break end
    end
    Menu.SetLabel("travel","distance",selected_distance)
    -- Movement diagnostic; Foenem uses its own acknowledged adapter protocol.
    local file=io.open(root.."/data/diagnostic.txt","w")
    if file then
        file:write(string.format("tick=%d\nmode=%s\nspeed=%.2f\nlimit=%.2f\nactive=%s\nenabled=%s\nmultiplier=%s\nvehicles=%d\nmenu=%s\nresult=%s\n",tick,mode,speed,limit,tostring(boost~=nil),control.enabled,control.multiplier,#vehicle_list,tostring(Menu.IsOpen()),clean(result)))
        file:write("vehicle_boost="..tostring(control.vehicleBoost==true).."\nvehicle_status="..clean(vehicleStatus).."\ndrone_boost="..tostring(control.droneBoost==true).."\ndrone_status="..clean(droneStatus).."\n")
        file:write("clickwarp_enabled="..tostring(control.clickwarp==true).."\nclickwarp_armed="..tostring(Clickwarp.isArmed()).."\nclickwarp_status="..clean(Clickwarp.status()).."\n")
        file:write("protection_requested="..tostring(control.immortal==true).."\nprotection_status="..clean(Protection.status()).."\n")
        file:close()
    end
end

Menu=require("ui").create(control,{
    root=root,
    reset=function() action="reset" end,
    refresh=function() action="refresh" end,
    teleport=function(nearest) action=nearest and "nearest" or "selected" end,
})

local Inspector=nil
local Foenem=require("foenem")
local inspection_reload=false
local inspection_requested=false
local function update()
    tick=tick+1
    if tick%4==1 then Foenem.update() end
    if tick%10==2 then
        local ok,err=pcall(InactiveESP.update,Foenem)
        if not ok then log("Inactive ESP: "..tostring(err)) end
    end
    mode,message=context()
    if tick%4==1 then Protection.update(controller,pawn,control,Menu,VehicleBoost.kind(pawn)) end
    local boostOk,boostError=pcall(VehicleBoost.update,controller,pawn,Menu.IsOpen(),control,Menu)
    if not boostOk then
        VehicleBoost.fail(boostError,control,Menu)
        log("Vehicle/drone experiment stopped: "..tostring(boostError))
    end
    if inspection_reload then
        inspection_reload=false
        local ok,module=pcall(dofile,root.."/runtime/ue4ss/Mods/FPVInGame/Scripts/inspection.lua")
        if ok then Inspector=module;inspection_requested=true else log("Inspection reload: "..tostring(module)) end
    end
    if inspection_requested and Inspector and is_character() then
        inspection_requested=false
        local ok,err=pcall(Inspector.capture,root,controller,pawn,movement)
        if not ok then log("Inspection: "..tostring(err)) end
    end
    if valid(pawn) and (not valid(last_pawn) or not same(last_pawn,pawn)) then
        restore();control.enabled="0";Menu.Set("run","enabled",false);last_pawn=pawn;action="refresh"
    end
    if not is_character() then restore() end
    apply_speed(is_character() and not Menu.IsOpen())
    if (is_character() or mode=="vehicle") and tick%20==1 then list_vehicles() end
    if mode=="waiting" then vehicle_list={} end
    if action then
        local next_action=action;action=nil
        log("Action="..next_action.." mode="..mode)
        if next_action=="reset" then restore()
        elseif next_action=="refresh" then refresh_options()
        elseif next_action=="nearest" or next_action=="selected" then teleport(next_action=="nearest") end
    end
    check_teleport()
    local kind=is_character() and "character" or VehicleBoost.kind(pawn)
    local address=valid(pawn) and pawn:GetAddress() or 0
    local events=Mouse.read(root,address,valid(controller) and valid(pawn) and not Menu.IsOpen())
    if events.middle then log("Clickwarp input="..tostring(events.source).." enabled="..tostring(control.clickwarp)) end
    if control.speedWheel and not Menu.IsOpen() then Options.wheel(kind,events.wheel,control,Menu) end
    local marker=Clickwarp.update(controller,pawn,kind,Menu.IsOpen(),control.clickwarp,events,tick,
        function(text)
            result=text;Menu.SetLabel("clickwarp","result",text)
            log(text.." mode="..mode.." kind="..kind)
        end,function(check)teleport_check=check end,teleport_check~=nil)
    local option=Options[kind]
    local speed=0
    if option and valid(pawn) then local v=pawn:GetVelocity();speed=math.sqrt(v.X*v.X+v.Y*v.Y+v.Z*v.Z)*.036 end
    DriveHUD.update(controller,kind,speed,option and Options.speed(kind,control[option.key]) or 0,option and control[option.enabled]==true,
        control.driveHud and not Menu.IsOpen(),marker)
    if tick%10==1 then update_ui() end
end

-- Keep strong Lua references for the lifetime of all registered callbacks.
-- Temporary closures can be collected while UE4SS retains their registry id.
local callbacks={}
_G.FPVInGameCallbacks=callbacks
callbacks.update=function()
    local ok,err=pcall(update)
    if not ok then
        Protection.stop(control,Menu)
        restore();VehicleBoost.stop(control,Menu);result="Ошибка: "..tostring(err)
        pcall(function() Menu.SetLabel("travel","result",result) end)
        if callbacks.lastError~=result then log(result);callbacks.lastError=result end
    else callbacks.lastError=nil end
    return false
end
callbacks.stop=function()
    Protection.stop(control,Menu)
    Clickwarp.cancel();control.clickwarp=false;Menu.Set("clickwarp","enabled",false)
    Foenem.off()
    VehicleBoost.stop(control,Menu)
    control.enabled="0";restore();Menu.Set("run","enabled",false);Menu.Close()
end
callbacks.nearest=function() action="nearest" end
callbacks.stopKey=function() ExecuteInGameThread(callbacks.stop) end
callbacks.inspectKey=function() inspection_reload=true end
callbacks.loop=LoopInGameThreadWithDelay(50,callbacks.update)
RegisterKeyBind(Key.F7,callbacks.nearest)
RegisterKeyBind(Key.F9,callbacks.stopKey)
RegisterKeyBind(Key.F8,callbacks.inspectKey)
log("FPV MENU v.1.0 (release): F6 menu, F7 nearest, F9 all off, F8 inspection.")
