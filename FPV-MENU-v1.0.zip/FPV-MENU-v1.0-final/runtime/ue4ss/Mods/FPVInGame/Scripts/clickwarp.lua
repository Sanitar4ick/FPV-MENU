local M={};local armed=false;local address,worldAddress,target=nil,nil,nil
local status="Выключен. Включи Clickwarp и нажми СКМ / F10."
local function valid(o) local ok,v=pcall(function()return o and o:IsValid()end);return ok and v end
local function vec(p)return {X=p.X,Y=p.Y,Z=p.Z}end
local function distance(a,b)return math.sqrt((a.X-b.X)^2+(a.Y-b.Y)^2+(a.Z-b.Z)^2)end
function M.cancel() armed=false;target=nil end
function M.isArmed()return armed end
function M.status()return status end
function M.setStatus(text)status=text end
function M.safeHit(hit)
    if not hit or not hit.ImpactPoint or not hit.ImpactNormal then return false end
    for _,axis in ipairs({"X","Y","Z"}) do
        local n=hit.ImpactPoint[axis];if type(n)~="number" or n~=n or math.abs(n)>1e9 then return false end
    end
    return type(hit.ImpactNormal.Z)=="number" and hit.ImpactNormal.Z>=.7
end
function M.update(pc,p,kind,menuOpen,enabled,events,tick,onResult,onTeleport,busy)
    local function report(text)status=text;onResult(text)end
    local eligible=valid(pc) and valid(p) and (kind=="vehicle" or kind=="character") and pc.Pawn:GetAddress()==p:GetAddress() and p:IsLocallyControlled()
    if not eligible then M.cancel();address=nil;status="Нужен пеший персонаж или управление автомобилем.";return end
    local world=p:GetWorld()
    if not valid(world) then M.cancel();return end
    if address~=p:GetAddress() or worldAddress~=world:GetAddress() then M.cancel();address=p:GetAddress();worldAddress=world:GetAddress() end
    if not enabled then M.cancel();status="Выключен. Включи Clickwarp и нажми СКМ / F10.";return end
    if menuOpen or events.escape then
        if armed then status="Выбор точки отменён. СКМ / F10 — выбрать снова." end
        M.cancel();return
    end
    if events.middle then
        armed=not armed;target=nil
        report(armed and "Clickwarp: выбор точки включён. Наведи прицел на землю." or "Clickwarp: выбор точки отменён.")
    end
    if not armed then return end
    local camera=pc.PlayerCameraManager
    local kismet=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    if not valid(camera) or not valid(kismet) then M.cancel();report("Clickwarp: камера недоступна.");return end
    local origin=camera:GetCameraLocation();local rotation=camera:GetCameraRotation()
    local yaw,pitch=math.rad(rotation.Yaw),math.rad(rotation.Pitch)
    local ray={X=math.cos(pitch)*math.cos(yaw),Y=math.cos(pitch)*math.sin(yaw),Z=math.sin(pitch)}
    local endpoint={X=origin.X+ray.X*200000,Y=origin.Y+ray.Y*200000,Z=origin.Z+ray.Z*200000}
    local hit={};local color={R=0,G=0,B=0,A=0}
    local collided=kismet:LineTraceSingle(p,origin,endpoint,0,false,{p},0,hit,true,color,color,0)
    target=nil
    if collided and M.safeHit(hit) then target={point=vec(hit.ImpactPoint),distance=distance(p:K2_GetActorLocation(),hit.ImpactPoint)/100} end
    if events.left then
        if busy then report("Clickwarp: проверяется предыдущий прыжок. Подожди и нажми ЛКМ снова.");return target or {message="Проверяется предыдущий прыжок…"} end
        if not target then report("Clickwarp: наведи прицел на свободную поверхность земли.");return {message="CLICKWARP · наведи прицел на землю\nСКМ / F10 / Esc — отмена"} end
        local bounds,extent={},{};p:GetActorBounds(true,bounds,extent,false)
        local before=vec(p:K2_GetActorLocation());local destination=vec(target.point)
        local bottomOffset=extent.Z+before.Z-bounds.Z
        if kind=="character" and valid(p.CapsuleComponent) then bottomOffset=p.CapsuleComponent:GetScaledCapsuleHalfHeight() end
        destination.Z=destination.Z+math.max(10,bottomOffset)+10
        local r=p:K2_GetActorRotation()
        if p:K2_TeleportTo(destination,{Pitch=r.Pitch,Yaw=r.Yaw,Roll=r.Roll}) then
            local movement=p:GetMovementComponent()
            if valid(movement) then movement:StopMovementImmediately() end
            onTeleport({pawn=p,world=world,origin=before,dest=vec(p:K2_GetActorLocation()),tick=tick,label="Clickwarp"})
            report("Clickwarp выполнен локально; проверяю сохранение позиции…")
        else report("Clickwarp: место занято, перемещение отменено.") end
        M.cancel()
        return
    end
    return target or {message="CLICKWARP · наведи прицел на землю\nСКМ / F10 / Esc — отмена"}
end
return M
