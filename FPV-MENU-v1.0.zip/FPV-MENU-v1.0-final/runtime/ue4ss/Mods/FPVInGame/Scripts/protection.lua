-- Host-only test using the game's GE_DamageImmunity. No loose-tag containers,
-- health writes, CDO edits or actor damage-flag changes.
local M={}
local effectPath="/Game/GameplayEffects/Character/GE_DamageImmunity.Default__GE_DamageImmunity_C"
local owned,uncertain
local requestedLastTick=false
local status="Выключено. Доступно в собственном лобби."
local function valid(o)
 local ok,v=pcall(function()return o~=nil and o:IsValid()end);return ok and v==true
end
local function same(a,b)return valid(a) and valid(b) and a:GetAddress()==b:GetAddress()end
local function get(o,k)local ok,v=pcall(function()return o[k]end);if ok then return v end end
local function playerState(o)
 local state=get(o,'CurPlayerState')
 return valid(state) and state or get(o,'PlayerState')
end
local function linkedOperator(record,pc)
 if not same(record.pc,pc) or not valid(record.pawn) then return false end
 if not same(playerState(pc),record.playerState) or not same(playerState(record.pawn),record.playerState) then return false end
 local owner=get(record.pawn,'PlayerController')
 return not valid(owner) or same(owner,pc)
end
local function count(asc,cls)
 local n=asc:GetGameplayEffectCount(cls,nil,false)
 assert(type(n)=='number' and n>=0,'Не удалось прочитать число эффектов защиты')
 return n
end
local function tags(asc)
 local n=asc:GetGameplayTagCount({TagName=FName('Gameplay.DamageImmunity')})
 assert(type(n)=='number' and n>=0,'Не удалось прочитать признак защиты')
 return n
end
local function disable(control,menu,message)
 control.immortal=false
 if menu then menu.Set('protection','enabled',false) end
 status=message
end
local function release()
 if not owned then return end
 local old=owned
 if not valid(old.pawn) or not valid(old.asc) then owned=nil;return end
 assert(old.pawn:HasAuthority(),'Ожидание полномочий для снятия эффекта')
 print('[FPV Protection exp4] remove owned handle='..old.handle)
 -- Remove only our one stack; preserve effects added independently by the game.
 local removed=old.asc:RemoveActiveGameplayEffect({Handle=old.handle},1)
 assert(removed==true or count(old.asc,old.cls)==0,'Снятие эффекта не подтверждено')
 owned=nil
end
local function schema()
 local context=StaticFindObject('/Script/GameplayAbilities.GameplayEffectContextHandle')
 local handle=StaticFindObject('/Script/GameplayAbilities.ActiveGameplayEffectHandle')
 assert(valid(context) and valid(handle),'Описание параметров эффекта недоступно')
 local contextFields,handleFound=0,false
 context:ForEachProperty(function()contextFields=contextFields+1 end)
 handle:ForEachProperty(function(p)
  local n=p:GetFName():ToString()
  if n=='Handle' then
   assert(p:GetFullName():match('^IntProperty '),'Неожиданный тип идентификатора эффекта')
   handleFound=true
  end
 end)
 -- Empty context is passed by value; reject a layout requiring nested marshaling.
 assert(contextFields==0 and handleFound,'Неподдерживаемая структура параметров эффекта')
end
function M.status()return status end
function M.stop(control,menu)
 requestedLastTick=false
 disable(control,menu,'Выключено.')
 local ok,e=pcall(release)
 if not ok then status='Ошибка снятия защиты: '..tostring(e) end
 if uncertain then status='Результат применения неизвестен. Повторное включение заблокировано до перезапуска игры.' end
 return ok and not uncertain
end
local function update(pc,pawn,control,menu,kind)
 if not control.immortal then release();return end
 if uncertain then disable(control,menu,'Результат применения неизвестен. Нужен перезапуск игры.');return end
 if not valid(pc) or not pc:IsLocalPlayerController() then
  release();status='Ожидание своего персонажа.';return
 end
 local remote=false
 if owned and not same(owned.pawn,pawn) then
  local current=get(pc,'Pawn')
  local drone=kind=='drone' and same(current,pawn)
  local transition=not valid(current) and not valid(pawn) and (owned.transitionTicks or 0)<10
  if (drone or transition) and linkedOperator(owned,pc) then
   owned.transitionTicks=transition and ((owned.transitionTicks or 0)+1) or 0
   pawn=owned.pawn;remote=true
  else release() end
 end
 if not remote and not same(pc.Pawn,pawn) then
  release();status='Ожидание своего персонажа.';return
 end
 if not pawn:HasAuthority() then
  disable(control,menu,'Недоступно на чужом сервере: защита не применена.');release();return
 end
 if not pawn:IsA('/Script/FPVKamikazeDrone.FPVCharacter') then
  release();status='Ожидание пешего персонажа.';return
 end
 local health,asc=pawn.HealthComponent,pawn.AbilitySystemComponent
 if not valid(health) or not valid(asc) then release();status='Компоненты персонажа недоступны.';return end
 if owned and not same(owned.asc,asc) then release() end
 local hp=health:GetHealth()
 assert(type(hp)=='number' and hp==hp,'Не удалось прочитать здоровье')
 if health:GetDeathState()~=0 or hp<=0 then
  disable(control,menu,'Персонаж погиб. Защита не подтвердилась.');release();return
 end
 if owned then
  if not remote then owned.transitionTicks=0 end
  if owned.remote~=remote then
   owned.remote=remote
   print('[FPV Protection exp4] operator retained='..tostring(remote)..'; handle='..owned.handle)
  end
  if tags(asc)==0 or count(asc,owned.cls)==0 then
   disable(control,menu,'Эффект закончился или снят игрой. Режим отключён.');release();return
  end
  if hp<owned.hp-0.01 then
   disable(control,menu,'Получен урон: эффект не обеспечил полную защиту.');release();return
  end
  owned.hp=hp
  status=remote and 'Защита тела оператора активна. Дрон остаётся уязвимым.' or 'Защита персонажа активна у хоста.'
  return
 end
 local effect=StaticFindObject(effectPath)
 assert(valid(effect),'Игровой эффект защиты не найден')
 local cls=effect:GetClass()
 assert(valid(cls),'Класс эффекта недоступен')
 local duration=effect.DurationPolicy
 assert(duration==1 or duration==2,'Эффект не имеет поддерживаемого времени действия')
 if count(asc,cls)>0 or tags(asc)>0 then
  status='Защита уже задана игрой. Дополнительный эффект не добавлен.';return
 end
 schema()
 print('[FPV Protection exp4] apply GE_DamageImmunity; host=true; health='..hp..'; duration_policy='..duration)
 -- Quarantine indeterminate results: no broad cleanup or repeated applications.
 uncertain=true
 local result=asc:BP_ApplyGameplayEffectToSelf(cls,1,{})
 local handle=result and result.Handle
 assert(type(handle)=='number' and handle>=0 and handle<=2147483647 and handle%1==0,'Игра не вернула пригодный идентификатор эффекта')
 owned={pawn=pawn,asc=asc,cls=cls,handle=handle,hp=hp,pc=pc,playerState=playerState(pc),remote=false,transitionTicks=0}
 uncertain=false
 assert(count(asc,cls)>0 and tags(asc)>0,'Эффект не подтвердил признак защиты')
 print('[FPV Protection exp4] applied handle='..handle..'; immunity tag confirmed; no damage sampled at activation')
 status='Защита персонажа активна у хоста.'
end
function M.update(pc,pawn,control,menu,kind)
 local manuallyDisabled=requestedLastTick and not control.immortal
 local ok,e=pcall(update,pc,pawn,control,menu,kind)
 if ok and manuallyDisabled then status='Выключено.' end
 if not ok then
  disable(control,menu,'Защита не включена: '..tostring(e))
  local cleaned,cleanupError=pcall(release)
  if not cleaned then status='Ошибка снятия защиты: '..tostring(cleanupError) end
 end
 if uncertain then status='Результат применения неизвестен. Повторное включение заблокировано до перезапуска игры.' end
 requestedLastTick=control.immortal==true
 return status
end
return M
