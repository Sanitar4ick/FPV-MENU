local M={};local hud,canvas,panel,speedText,limitText,hintText,marker,markerSlot,owner
local serial=0
local function valid(o) local ok,v=pcall(function()return o and o:IsValid()end);return ok and v end
local function make(path,outer,label)
    local cls=StaticFindObject("/Script/UMG."..path)
    assert(valid(cls),"HUD class unavailable: "..path)
    return StaticConstructObject(cls,outer,FName("FPVDrive_"..serial.."_"..label))
end
local function label(parent,text,size,color,id)
    local t=make("TextBlock",parent,id);t:SetText(FText(text));t.Font.Size=size
    t:SetColorAndOpacity({SpecifiedColor=color,ColorUseRule=0});return t
end
function M.destroy()
    if valid(hud) then pcall(function()hud:RemoveFromParent()end) end
    hud=nil;owner=nil
end
local function create(pc)
    M.destroy();serial=serial+1;owner=pc:GetAddress()
    hud=make("UserWidget",pc,"Root");local tree=make("WidgetTree",hud,"Tree");hud.WidgetTree=tree
    canvas=make("CanvasPanel",tree,"Canvas");tree.RootWidget=canvas
    panel=make("Border",canvas,"Panel");panel:SetBrushColor({R=.008,G=.014,B=.025,A=.82})
    panel:SetPadding({Left=14,Top=8,Right=14,Bottom=8})
    local box=make("VerticalBox",panel,"Rows");panel:SetContent(box)
    speedText=label(box,"",25,{R=1,G=1,B=1,A=1},"Speed");box:AddChild(speedText)
    limitText=label(box,"",16,{R=.3,G=.8,B=1,A=1},"Limit");box:AddChild(limitText)
    hintText=label(box,"",11,{R=.65,G=.7,B=.8,A=1},"Hint");box:AddChild(hintText)
    local slot=canvas:AddChildToCanvas(panel)
    slot:SetAnchors({Minimum={X=1,Y=.15},Maximum={X=1,Y=.15}})
    slot:SetAlignment({X=1,Y=0});slot:SetPosition({X=-32,Y=0});slot:SetAutoSize(true)
    marker=label(canvas,"",19,{R=1,G=.9,B=0,A=1},"WarpMarker")
    markerSlot=canvas:AddChildToCanvas(marker);markerSlot:SetAutoSize(true);markerSlot:SetAlignment({X=.5,Y=.5})
    hud:AddToViewport(950);hud:SetVisibility(3) -- self/children cannot intercept the game's pointer
    panel:SetVisibility(1);marker:SetVisibility(1)
end
function M.update(pc,kind,speed,limit,enabled,show,warp)
    if not valid(pc) then M.destroy();return end
    if not valid(hud) or owner~=pc:GetAddress() or not hud:IsInViewport() then create(pc) end
    local visible=show and (kind=="vehicle" or kind=="drone")
    panel:SetVisibility(visible and 3 or 1)
    if visible then
        speedText:SetVisibility(kind=="vehicle" and 3 or 1)
        speedText:SetText(FText(string.format("%03.0f  КМ/Ч",speed)))
        limitText:SetText(FText(string.format("ЛИМИТ %d КМ/Ч  ·  %s",limit,enabled and "ВКЛ" or "ВЫКЛ")))
        hintText:SetText(FText(enabled and "КОЛЕСО ±25 КМ/Ч" or "Разгон выключен"))
    end
    local visibleMarker=false
    if warp and warp.point then
        local p={}
        if pc:ProjectWorldLocationToScreen(warp.point,p,false) then
            local lib=StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary")
            local scale=valid(lib) and lib:GetViewportScale(pc) or 1
            markerSlot:SetAnchors({Minimum={X=0,Y=0},Maximum={X=0,Y=0}})
            markerSlot:SetPosition({X=p.X/math.max(.1,scale),Y=p.Y/math.max(.1,scale)})
            marker:SetText(FText(string.format("⊕  %.0f м\nЛКМ — переместиться\nСКМ / F10 / Esc — отмена",warp.distance)))
            visibleMarker=true
        end
    elseif warp and warp.message then
        markerSlot:SetAnchors({Minimum={X=.5,Y=.5},Maximum={X=.5,Y=.5}})
        markerSlot:SetPosition({X=0,Y=55})
        marker:SetText(FText(warp.message));visibleMarker=true
    end
    marker:SetVisibility(visibleMarker and 3 or 1)
end
return M

