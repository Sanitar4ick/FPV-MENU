local M={vehicle={min=30,max=300,default=120,key="vehicleSpeed",section="vehicleboost",enabled="vehicleBoost"},drone={min=30,max=400,default=180,key="droneSpeed",section="droneboost",enabled="droneBoost"}}
function M.speed(kind,value)
    local c=assert(M[kind]);local n=tonumber(value)
    if not n or n~=n or math.abs(n)>1e9 then n=c.default end
    return math.max(c.min,math.min(c.max,math.floor(n/5+.5)*5))
end
function M.wheel(kind,steps,control,menu)
    local c=M[kind]
    if not c or control[c.enabled]~=true or not steps or steps==0 then return false end
    control[c.key]=M.speed(kind,M.speed(kind,control[c.key])+steps*25)
    if menu then menu.Set(c.section,"speed",control[c.key]) end
    return true
end
return M
