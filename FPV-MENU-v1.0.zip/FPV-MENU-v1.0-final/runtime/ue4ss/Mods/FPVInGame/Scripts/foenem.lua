-- Unified UI for the original Foenem backend; all writes go through a version-locked adapter.
local M={}
local schema=require("foenem-schema")
local Profiles=require("menu-profiles")
local profileFlight,profileBusy,profileResult
local byKey,bindings,values,queued,pending={},{},{},{},{}
local Menu,root,session,ready,sequence,lastAck=nil,nil,nil,false,0,0
local localMessage="Ожидание подключения…"
local profileName,profileSelected,profilesSignature="Мой профиль","__none",""
for _,s in ipairs(schema) do byKey[s.key]=s;values[s.key]=s.initial end
local function copy(v) if type(v)~="table" then return v end local t={} for i,n in ipairs(v) do t[i]=n end return t end
local function encode(v)
    if type(v)=="boolean" then return v and "1" or "0" end
    if type(v)=="table" then local t={} for i,n in ipairs(v) do t[i]=string.format("%.6f",n) end return table.concat(t,",") end
    return tostring(v)
end
local function decode(s,text)
    if s.type=="color" then local t={} for n in text:gmatch("[^,]+") do t[#t+1]=tonumber(n) end if #t==4 then return t end return nil end
    return tonumber(text)
end
local function command(key,value)
    if not ready then localMessage="Модуль не подключён: настройка не применена.";return false end
    queued[#queued+1]={key=key,value=tostring(value or "")};return true
end
local function change(key,value)
    if not ready then
        localMessage="Модуль не подключён: настройка не применена."
        for _,b in ipairs(bindings) do if b.key==key then b.last=nil end end
        return
    end
    values[key]=copy(value)
    -- Coalesce slider updates, but preserve ordering relative to profile operations.
    for i=#queued,1,-1 do
        if queued[i].key:sub(1,1)=="@" then break end
        if queued[i].key==key then queued[i].value=encode(value);return end
    end
    queued[#queued+1]={key=key,value=encode(value)}
end
-- Hidden appearance options are fixed for every connection/profile, without
-- enabling ESP, aiming or other gameplay features. F9 still turns those off.
local fixed={skeletonOutlineEsp=1,boxCornersOnly=0,boxOutlineEsp=1,boxFillEsp=1,boxFillAlpha=10,
    worldOutlineEsp=1,worldBoxCornersOnly=0,worldBoxFillEsp=1,worldBoxFillAlpha=10,uiScaleIdx=2}
for _,s in ipairs(schema) do if s.type=="color" then fixed[s.key]=copy(s.initial) end end
local function fixedDefaults() for key,value in pairs(fixed) do change(key,value) end end
M.fixedDefaults=fixed
local function section(id,title,tab,items,collapsed)
    Menu.Register({id=id,title=title,tab=tab,items=items,collapsible=collapsed~=nil,collapsed=collapsed==true})
end
local function bind(key,sectionId,itemId,component,bit)
    bindings[#bindings+1]={key=key,section=sectionId,id=itemId,component=component,bit=bit}
end
local function item(key,sectionId)
    local s=assert(byKey[key],key)
    bind(key,sectionId,key)
    if s.type=="bool" then return {type="checkbox",id=key,label=s.label,asButton=true,default=s.initial~=0,onChange=function(on) change(key,on and 1 or 0) end} end
    return {type="slider",id=key,label=s.label,min=s.min,max=math.max(s.max,tonumber(s.initial) or s.max),step=s.step,default=s.initial,
        valueFormat=s.step<1 and "%.2f" or "%.0f",onChange=function(n) change(key,n) end}
end
local function group(id,title,tab,keys,collapsed)
    local items={} for _,k in ipairs(keys) do items[#items+1]=item(k,id) end
    section(id,title,tab,items,collapsed)
end
local function profileAction(action)
    if profileBusy then profileResult="Дождись завершения операции с профилем.";return end
    if not ready then profileResult="Нет подключения: профиль не изменён.";return end
    local name=action=="@save" and profileName or profileSelected
    if name=="__none" or name:match("^%s*$") then profileResult="Сначала выбери профиль или укажи имя.";return end
    if not Profiles.validName(name) then profileResult="Имя: до 60 символов, без служебных знаков и точки или пробела в конце.";return end
    local plan,err,legacy
    if action=="@load" then plan,err,legacy=Profiles.load(name)
    elseif action=="@save" then
        plan,err=Profiles.capture()
        if plan then local ok;ok,err=Profiles.stage(name,plan);if not ok then plan=nil end end
    end
    if err then profileResult=err;return end
    queued[#queued+1]={key=action,value=name,profile={action=action,name=name,plan=plan,legacy=legacy}}
    profileBusy=true;profileResult="Применение…"
end
function M.bindExtras(control) Profiles.bind(root,control,Menu) end
function M.attach(menu,base)
    Menu=menu;root=assert(base)
    group("aim","Прицеливание","Weapon",{"aimbotEnabled","aimbotSilent","aimbotAutoAim","aimbotAutoFire","autoFireFriendly","noSpread"},false)
    group("targets","Выбор цели","Weapon",{"aimbotTargetPlayers","aimbotTargetDrones","aimbotVisibleOnly","aimbotIgnoreDowned"},true)
    group("aimsettings","Угол, дальность и плавность","Weapon",{"aimbotFov","aimbotShowFov","aimbotMaxDistM","aimbotSmoothInv"},true)
    local bones={}
    -- Order confirmed from the original six-entry bone selector table.
    for i,name in ipairs({"Голова","Шея","Грудь","Таз","Руки","Ноги"}) do
        local bit=2^(i-1);bind("aimbotBoneMask","bones","bone"..i,nil,bit)
        bones[#bones+1]={type="checkbox",id="bone"..i,label=name,asButton=true,default=math.floor(values.aimbotBoneMask/bit)%2==1,
            onChange=function(on) local v=tonumber(values.aimbotBoneMask) or 0;local old=math.floor(v/bit)%2==1;if old~=on then change("aimbotBoneMask",v+(on and bit or -bit)) end end}
    end
    section("bones","Части тела","Weapon",bones,true)
    bind("aimbotHotkey","hotkey","code")
    section("hotkey","Клавиша прицеливания","Weapon",{
        {type="label",id="current",label="Текущая: правая кнопка мыши"},
        {type="button",id="capture",label="Назначить клавишу",onClick=function() command("@capture","") end},
        {type="number",id="code",label="Код клавиши",min=1,max=255,integer=true,default=2,onChange=function(n) change("aimbotHotkey",n) end},
    },true)
    group("players","Игроки","ESP/WH",{"showSelfEsp","nameEsp","healthEsp","weaponLabelEsp","playerDistanceEsp","playerMaxDistance","snaplinesEsp","visionVectorEsp"},false)
    group("skeleton","Скелет и голова","ESP/WH",{"skeletonEsp","skeletonThickness","headDotEsp","headDotSize"},true)
    group("boxes","Рамки игроков","ESP/WH",{"boxEsp","box3DEsp"},true)
    group("drones","Дроны","ESP/WH",{"droneEsp","droneLabelEsp","droneDistanceEsp"},true)
    group("vehicles","Транспорт","ESP/WH",{"vehicleEsp","vehicleTeamColor","vehicleLabelEsp","vehicleDistanceEsp"},true)
    group("supplies","Ящики с дронами","ESP/WH",{"supplyBoxEsp","supplyBoxNameEsp","supplyBoxLabelEsp","supplyBoxTimerEsp","supplyBoxDistanceEsp"},true)
    group("ammo","Боеприпасы","ESP/WH",{"ammoPickupEsp","ammoPickupLabelEsp","ammoPickupTimerEsp","ammoPickupDistanceEsp"},true)
    group("items","Ящики с гранатами","ESP/WH",{"itemPickupEsp","itemPickupLabelEsp","itemPickupTimerEsp","itemPickupDistanceEsp"},true)
    group("grenades","Гранаты","ESP/WH",{"grenadeEsp","grenadeDistanceEsp","grenadeRadiusEsp"},true)
    group("worldboxes","Дальность объектов","ESP/WH",{"worldMaxDistance"},true)
    group("chams","Подсветка моделей","ESP/WH",{"chamsEnabled","chamsVisibleOnly","chamsRevealHidden"},true)
    section("profiles","Профили","Профили",{
        {type="dropdown",id="selected",label="Сохранённые настройки",searchable=true,options={{label="Нет профилей",value="__none"}},default="__none",maxVisible=10,listMaxHeight=150,
            onChange=function(v) profileSelected=v end},
        {type="button",id="load",label="Загрузить выбранный",variant="primary",onClick=function() profileAction("@load") end},
        {type="textinput",id="name",label="Имя профиля",default=profileName,maxLength=60,onChange=function(v) profileName=v end},
        {type="button",id="save",label="Сохранить под этим именем",onClick=function() profileAction("@save") end},
        {type="button",id="delete",label="Удалить выбранный",variant="danger",confirm={title="Удалить профиль?",message="Будет удалена выбранная копия профиля в FPV MENU.",confirmLabel="Удалить",cancelLabel="Отмена"},onClick=function() profileAction("@delete") end},
        {type="button",id="refresh",label="Обновить список",onClick=function() command("@refresh","") end},
        {type="label",id="result",label=""},
    })
end
function M.off()
    for _,q in ipairs(queued) do if q.profile and q.key=="@save" then Profiles.abort(q.value) end end
    queued={}
    if profileFlight then profileFlight.cancelled=true else profileBusy=false end
    command("@off","");fixedDefaults()
end
local function flush()
    if not ready or #queued==0 or profileFlight then return end
    -- Isolate a profile command from all other commands until its ACK. This
    -- prevents a later success from hiding its error and applying half a profile.
    if queued[1].profile and next(pending)~=nil then return end
    local f=io.open(root.."/data/commands-"..session..".txt","ab")
    if not f then localMessage="Не удалось передать настройку. Попробуй ещё раз.";return end
    local text,planned={},{}
    local count,flight=0,nil
    for i,q in ipairs(queued) do
        if q.profile and i>1 then break end
        sequence=sequence+1
        text[#text+1]=sequence.."\t"..q.key.."\t"..q.value:gsub("[\r\n\t]","").."\n"
        planned[q.key]=sequence
        count=i
        if q.profile then flight=q.profile;flight.sequence=sequence;break end
    end
    local ok=f:write(table.concat(text));f:close()
    if ok then
        for k,n in pairs(planned) do pending[k]=n end
        for _=1,count do table.remove(queued,1) end
        profileFlight=flight;localMessage="Применение…"
    else localMessage="Ошибка записи настроек." end
end
local function syncBindings()
    for _,b in ipairs(bindings) do
        local v=values[b.key]
        if b.component then v=v[b.component] elseif b.bit then v=math.floor(v/b.bit)%2==1 elseif byKey[b.key].type=="bool" then v=v~=0 end
        if v~=b.last then Menu.Set(b.section,b.id,v);b.last=v end
    end
end
function M.update()
    if not root then return end
    local f=io.open(root.."/data/foenem-state.txt","r")
    local data={}
    if f then local text=f:read("*a");f:close();for k,v in text:gmatch("([^\r\n=]+)=([^\r\n]*)") do data[k]=v end end
    ready=data.bridge=="ready" and data.session and data.session:match("^%d+%-%d+$")~=nil and math.abs(os.time()-(tonumber(data.timestamp) or 0))<=4
    if ready then
        if session~=data.session then
            session=data.session;queued={};pending={};profileFlight=nil;profileBusy=false
            sequence=tonumber(data.ack) or 0;lastAck=sequence
            fixedDefaults()
        end
        local ack=tonumber(data.ack) or 0
        for k,n in pairs(pending) do if n<=ack then pending[k]=nil end end
        if profileFlight and ack>=profileFlight.sequence then
            local job=profileFlight;profileFlight=nil;profileBusy=false
            if data.error and data.error~="" then
                if job.action=="@save" then Profiles.abort(job.name) end
                profileResult="Профиль не применён: "..data.error
            else
                local ok,err=true,nil
                if job.action=="@save" then ok,err=Profiles.commit(job.name)
                elseif job.action=="@delete" then ok,err=Profiles.delete(job.name)
                elseif not job.cancelled then ok,err=Profiles.apply(job.plan) end
                profileResult=err or (job.cancelled and "Операция завершена. Функции отключены через F9." or
                    (job.action=="@save" and "Профиль сохранён." or job.action=="@delete" and "Профиль удалён." or
                    (job.legacy and "Профиль загружен. Дополнительные режимы выключены: их нет в старом профиле." or "Профиль загружен.")))
            end
            if job.action=="@load" then fixedDefaults() end
        end
        local waiting={} for _,q in ipairs(queued) do waiting[q.key]=true end
        for _,s in ipairs(schema) do
            if data[s.key] and not pending[s.key] and not waiting[s.key] then local v=decode(s,data[s.key]);if v~=nil then values[s.key]=v end end
        end
        if ack>lastAck then localMessage=data.error~="" and ("Не применено: "..data.error) or "Настройки применены.";lastAck=ack
        elseif #queued==0 and next(pending)==nil and localMessage=="Ожидание подключения…" then localMessage="Подключено." end
        if data.capture=="1" then localMessage="Нажми нужную клавишу. Esc — отмена." end
        local names={} for k,v in pairs(data) do if k:match("^profile%.%d+$") then names[#names+1]=v end end table.sort(names)
        local signature=table.concat(names,"\n")
        if signature~=profilesSignature then
            profilesSignature=signature;local options,found={},false
            for _,n in ipairs(names) do options[#options+1]={label=n,value=n};if n==profileSelected then found=true end end
            if #options==0 then options={{label="Нет профилей",value="__none"}} end
            if not found then profileSelected=options[1].value end
            Menu.SetOptions("profiles","selected",options,profileSelected)
        end
        local key=tonumber(values.aimbotHotkey) or 2
        local keyName=({[1]="ЛКМ",[2]="ПКМ",[4]="Средняя кнопка мыши",[5]="Mouse 4",[6]="Mouse 5",[16]="Shift",[17]="Ctrl",[18]="Alt",[32]="Пробел"})[key] or ((key>=65 and key<=90) and string.char(key) or ("код "..key))
        Menu.SetLabel("hotkey","current","Текущая: "..keyName)
        flush()
    else
        if profileBusy then profileResult="Связь прервана. Результат операции с профилем не подтверждён." end
        queued={};pending={};profileFlight=nil;profileBusy=false;session=nil
        localMessage=data.error and data.error~="" and ("Модуль: "..data.error) or "Нет подключения. Запусти загрузчик FPV MENU."
    end
    if Menu.SetConnection then Menu.SetConnection(ready and "МОДУЛЬ: ПОДКЛЮЧЁН" or "МОДУЛЬ: НЕТ СВЯЗИ") end
    syncBindings()
    Menu.SetLabel("profiles","result",profileResult or "")
    if Menu.SetNotice then
        local err=(data.error and data.error~="" and data.error) or (localMessage:match("^Не ") and localMessage) or (localMessage:match("^Ошибка") and localMessage)
        Menu.SetNotice(err and ("Не применено: "..err) or nil)
    end
end
M.send=command
M.identity=function()return ready and session or nil end
return M
