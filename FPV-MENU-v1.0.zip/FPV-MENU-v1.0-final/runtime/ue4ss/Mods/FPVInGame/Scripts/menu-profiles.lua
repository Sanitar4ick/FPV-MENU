-- Additional settings share the native profile transaction through an ACK barrier.
-- Plain data only: no executable profile content and no game/native calls here.
local M={}
local fields={
 {"enabled","run","enabled","flag",0,1,0},
 {"multiplier","run","multiplier","string",1,10,2},
 {"vehicleBoost","vehicleboost","enabled","bool",0,1,0},
 {"vehicleMultiplier","vehicleboost","power","number",1,10,3},
 {"vehicleSpeed","vehicleboost","speed","number",30,300,120},
 {"droneBoost","droneboost","enabled","bool",0,1,0},
 {"droneMultiplier","droneboost","multiplier","number",1,10,2},
 {"droneRamp","droneboost","ramp","number",.2,3,.75},
 {"droneSpeed","droneboost","speed","number",30,400,180},
 {"droneSteering","droneboost","steering","number",0,100,50},
 {"driveHud","drivehud","visible","bool",0,1,1},
 {"speedWheel","drivehud","wheel","bool",0,1,1},
 {"clickwarp","clickwarp","enabled","bool",0,1,0},
 {"immortal","protection","enabled","bool",0,1,0},
}
local control,Menu,root
function M.bind(base,c,menu) root=base;control=c;Menu=menu end
function M.validName(name)
 if type(name)~="string" or #name==0 or #name>160 or name:find('[<>:"/\\|?*=%z\1-\31]') or name:find('[. ]$') then return false end
 local stem=name:upper():match('^([^.]*)')
 if stem=="CON" or stem=="PRN" or stem=="AUX" or stem=="NUL" or stem:match('^COM[1-9]$') or stem:match('^LPT[1-9]$') then return false end
 local ok,units=pcall(function()local n=0;for _,c in utf8.codes(name)do n=n+(c>65535 and 2 or 1)end;return n end)
 return ok and units<=60
end
local function validate(values)
 local plan={}
 for _,f in ipairs(fields) do
  local n=tonumber(values[f[1]])
  if not n or n~=n or n<f[5] or n>f[6] or ((f[4]=="bool" or f[4]=="flag") and n~=0 and n~=1) then
   return nil,"Некорректный параметр профиля: "..f[1]
  end
  plan[f[1]]=n
 end
 return plan
end
function M.capture()
 local values={}
 for _,f in ipairs(fields) do
  local v=control[f[1]]
  if v==nil then v=f[7] elseif type(v)=="boolean" then v=v and 1 or 0 end
  values[f[1]]=v
 end
 return validate(values)
end
function M.apply(values)
 local plan,err=validate(values);if not plan then return nil,err end
 for _,f in ipairs(fields) do
  local n=plan[f[1]]
  control[f[1]]=n
  if f[4]=="bool" then control[f[1]]=n==1
  elseif f[4]=="flag" then control[f[1]]=n==1 and "1" or "0"
  elseif f[4]=="string" then control[f[1]]=tostring(n) end
  local value=n
  if f[4]=="bool" or f[4]=="flag" then value=n==1 end
  Menu.Set(f[2],f[3],value)
 end
 control.shiftOnly="1"
 return true
end
local function hex(s)return (s:gsub(".",function(c)return string.format("%02x",c:byte())end))end
local function path(name)
 -- Bounded ASCII file names also work with Windows Lua io and Cyrillic profile names.
 local a,b=2166136261,5381
 for i=1,#name do a=((a ~ name:byte(i))*16777619)&0xffffffff;b=(b*33+name:byte(i))&0xffffffff end
 return root.."/data/profiles/fpv-"..string.format("%08x%08x",a,b)..".extra"
end
local function read(file)
 local f=io.open(file,"rb");if not f then return nil end
 local body=f:read(16385) or "";f:close();return body
end
local function parse(name,body)
 if #body>16384 or body:sub(1,12)~="FPV_EXTRA_1\n" then return nil,"Повреждён дополнительный профиль." end
 local values={}
 for line in body:gmatch("[^\r\n]+") do
  if line~="FPV_EXTRA_1" then
   local key,value=line:match("^([%w_]+)=(.*)$")
   if not key or values[key]~=nil then return nil,"Повреждён дополнительный профиль." end
   values[key]=value
  end
 end
 if values.name~=hex(name) then return nil,"Имя профиля не совпадает с сохранёнными данными." end
 return validate(values)
end
function M.load(name)
 local file=path(name)
 if read(file..".pending") or read(file..".bak") then return nil,"Сохранение профиля не завершено. Сохрани его заново." end
 local body=read(file)
 if not body then
  local defaults={};for _,f in ipairs(fields)do defaults[f[1]]=f[7] end
  return defaults,nil,true
 end
 return parse(name,body)
end
function M.stage(name,values)
 local plan,err=validate(values);if not plan then return nil,err end
 local existing=read(path(name))
 if existing and existing:match("\nname=([^\r\n]+)")~=hex(name) then return nil,"Имя профиля не совпадает с сохранёнными данными." end
 local lines={"FPV_EXTRA_1","name="..hex(name)}
 for _,f in ipairs(fields) do lines[#lines+1]=f[1].."="..tostring(plan[f[1]]) end
 local f=io.open(path(name)..".pending","wb");if not f then return nil,"Не удалось записать профиль." end
 local ok=f:write(table.concat(lines,"\n").."\n");local closed=f:close()
 if not ok or not closed then return nil,"Не удалось полностью записать профиль." end
 return true
end
function M.abort(name) os.remove(path(name)..".pending") end
function M.commit(name)
 local file=path(name)
 if read(file) then
  os.remove(file..".bak")
  if not os.rename(file,file..".bak") then return nil,"Не удалось обновить профиль. Повтори сохранение." end
 end
 if not os.rename(file..".pending",file) then
  os.rename(file..".bak",file)
  return nil,"Профиль сохранён не полностью. Повтори сохранение."
 end
 os.remove(file..".bak")
 return true
end
function M.delete(name)
 local file=path(name)
 for _,suffix in ipairs({"",".pending",".bak"}) do
  if read(file..suffix) and not os.remove(file..suffix) then return nil,"Не удалось удалить дополнительные настройки профиля." end
 end
 return true
end
return M
