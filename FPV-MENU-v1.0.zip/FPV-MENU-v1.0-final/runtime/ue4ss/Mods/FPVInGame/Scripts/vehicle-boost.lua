-- Experimental local movement adapters. No RPCs, global actor scans, or physics ownership changes.
local M={}
local Options=require("movement-options")
local journal,lastPawn,lastTime,clock=nil,nil,nil,nil
local fault=nil
local physicalRamp=0
local droneImpulses,lastDroneDelta=0,0
local text={vehicle="Выключено. Сядь за руль транспорта.",drone="Выключено. Переключись на ударный дрон."}
local function valid(o) local ok,v=pcall(function() return o~=nil and o:IsValid() end);return ok and v end
local function same(a,b) if not valid(a) or not valid(b) then return false end local ok,v=pcall(function() return a:GetAddress()==b:GetAddress() end);return ok and v end
local function get(o,key) local ok,v=pcall(function() return o[key] end);if ok then return v end end
local function finite(n) return type(n)=="number" and n==n and math.abs(n)<1e12 end
local function bounded(n,lo,hi,default) n=tonumber(n);if not finite(n) then return default end return math.max(lo,math.min(hi,n)) end
local function hasClass(o,name)
    if not valid(o) then return false end
    local ok,v=pcall(function()
        local c=o:GetClass()
        for _=1,16 do
            if not valid(c) then break end
            if c:GetFName():ToString()==name then return true end
            c=c:GetSuperStruct()
        end
        return false
    end)
    return ok and v
end
local function kind(p)
    if hasClass(p,"BP_Spectator_C") or hasClass(p,"SpectatorPawn") then return "spectator" end
    if hasClass(p,"BP_Striker_C") then return "drone" end
    if hasClass(p,"BP_Drone_FPV_C") then return "drone" end
    if hasClass(p,"BP_Vehicle_Base_C") then return "vehicle" end
    if hasClass(p,"BP_Drone_Base_C") then return "unknownDrone" end
    return "other"
end
M.kind=kind
function M.restore()
    if not journal then return true end
    if not valid(journal.object) then journal=nil;return true end
    local failed={}
    for key,value in pairs(journal.original) do
        local ok=pcall(function() journal.object[key]=value end)
        if not ok then failed[key]=value end
    end
    if next(failed) then journal.pendingRestore=true;return false end
    journal=nil;return true
end
function M.stop(control,menu)
    physicalRamp=0
    fault=nil
    control.vehicleBoost=false;control.droneBoost=false
    local restored=M.restore();lastTime=nil
    text.vehicle="Выключено. Дополнительный разгон прекращён."
    text.drone=restored and "Выключено. Исходные параметры восстановлены." or "Не удалось восстановить параметры; повторю попытку."
    if menu then menu.Set("vehicleboost","enabled",false);menu.Set("droneboost","enabled",false) end
end
function M.fail(err,control,menu)
    M.stop(control,menu)
    fault="Эксперимент отключён: "..tostring(err)
    text.vehicle=fault;text.drone=fault
end
-- Possession suspends physical effects, but preserves both user preferences.
local function changePawn(control,menu)
    local vehicleArmed,droneArmed=control.vehicleBoost==true,control.droneBoost==true
    M.stop(control,nil)
    control.vehicleBoost=vehicleArmed;control.droneBoost=droneArmed
    if menu then menu.Set("vehicleboost","enabled",vehicleArmed);menu.Set("droneboost","enabled",droneArmed) end
end
-- Delta velocity along heading, capped by total 3D speed and elapsed GAME time.
function M.impulse(velocity,heading,limit,acceleration,dt,throttle)
    local x,y,z=heading.X,heading.Y,heading.Z
    if not (finite(x) and finite(y) and finite(z) and finite(velocity.X) and finite(velocity.Y) and finite(velocity.Z)) then return nil end
    local length=math.sqrt(x*x+y*y+z*z);if length<.001 then return nil end
    x,y,z=x/length,y/length,z/length
    local speed2=velocity.X^2+velocity.Y^2+velocity.Z^2
    if speed2>=limit^2 then return nil end
    local along=velocity.X*x+velocity.Y*y+velocity.Z*z
    local room=math.max(0,-along+math.sqrt(math.max(0,along*along+limit*limit-speed2)))
    local step=math.min(room,acceleration*math.max(0,math.min(.1,dt))*math.max(0,math.min(1,throttle)))
    if step<=.001 then return nil end
    return {X=x*step,Y=y*step,Z=z*step}
end
-- Rotate velocity toward the nose at a bounded rate without increasing its magnitude.
-- This assists momentum through turns; it does not rotate the actor or override pilot input.
function M.steer(v,h,rate,dt)
    if not (finite(v.X) and finite(v.Y) and finite(v.Z) and finite(h.X) and finite(h.Y) and finite(h.Z)) then return nil end
    local speed=math.sqrt(v.X*v.X+v.Y*v.Y+v.Z*v.Z)
    local length=math.sqrt(h.X*h.X+h.Y*h.Y+h.Z*h.Z)
    if speed<30/.036 or length<.001 or not finite(rate) or rate<=0 or not finite(dt) or dt<=0 then return nil end
    local x,y,z=v.X/speed,v.Y/speed,v.Z/speed
    local hx,hy,hz=h.X/length,h.Y/length,h.Z/length
    local dot=math.max(-1,math.min(1,x*hx+y*hy+z*hz))
    local tx,ty,tz=hx-dot*x,hy-dot*y,hz-dot*z
    local side=math.sqrt(tx*tx+ty*ty+tz*tz)
    if side<.00001 then return nil end -- no arbitrary turn axis for exact reverse flight
    local angle=math.min(math.acos(dot),math.min(4,rate)*math.min(.1,dt))
    local c,s=math.cos(angle),math.sin(angle)/side
    return {X=speed*(x*c+tx*s)-v.X,Y=speed*(y*c+ty*s)-v.Y,Z=speed*(z*c+tz*s)-v.Z}
end
local function gameTime(p)
    if not valid(clock) then clock=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary") end
    if not valid(clock) then return nil end
    local ok,t=pcall(function() return clock:GetGameTimeInSeconds(p) end)
    if ok and finite(t) then return t end
end
local function physicalDrone(p,control,dt)
    local body=get(p,"Body")
    if not hasClass(body,"PrimitiveComponent") or not same(body:GetOwner(),p) then physicalRamp=0;return "Физический корпус дрона недоступен." end
    if not body:IsSimulatingPhysics(FName("None")) then physicalRamp=0;return "Корпус дрона не симулирует физику; помощь не применяется." end
    -- Live owned-client capture: Throttle follows input; CurThrottle stays zero during flight.
    local throttle=get(p,"Throttle")
    if not finite(throttle) or throttle<0 or throttle>1 then physicalRamp=0;return "Не удалось прочитать газ дрона; помощь не применяется." end
    if throttle<.05 then physicalRamp=0;return "Готово: добавь газ на дроне." end
    if not dt or dt<=0 then return "Ожидание игрового времени; помощь не применяется." end
    local multiplier=bounded(control.droneMultiplier,1,10,2)
    if multiplier<=1 then physicalRamp=0;return "Сила ×1: дополнительный разгон отключён." end
    local seconds=bounded(control.droneRamp,.2,3,.75)
    physicalRamp=math.min(seconds,physicalRamp+dt)
    local target=Options.speed("drone",control.droneSpeed)/.036
    local velocity=body:GetPhysicsLinearVelocity(FName("None"))
    local heading=p:GetActorForwardVector()
    local steer=M.steer(velocity,heading,bounded(control.droneSteering,0,100,50)*.04*(physicalRamp/seconds),dt)
    if steer then velocity={X=velocity.X+steer.X,Y=velocity.Y+steer.Y,Z=velocity.Z+steer.Z} end
    local delta=M.impulse(velocity,heading,target,800*(multiplier-1)*(physicalRamp/seconds),dt,throttle)
    if steer then
        delta=delta or {X=0,Y=0,Z=0}
        delta={X=delta.X+steer.X,Y=delta.Y+steer.Y,Z=delta.Z+steer.Z}
    end
    if delta then
        body:AddImpulse(delta,FName("None"),true)
        droneImpulses=droneImpulses+1
        lastDroneDelta=math.sqrt(delta.X^2+delta.Y^2+delta.Z^2)*.036
    end
    return string.format("Физический разгон камикадзе · предел помощи %.0f км/ч",target*.036)
end
local function drone(p,control,dt)
    if journal and journal.pendingRestore and not M.restore() then return "Не удалось восстановить прежние параметры; разгон отключён." end
    if hasClass(p,"BP_Drone_FPV_C") then
        if not M.restore() then return "Ожидание восстановления прежних параметров." end
        return physicalDrone(p,control,dt)
    end
    physicalRamp=0
    local component=get(p,"FloatingPawnMovement")
    if not hasClass(component,"FloatingPawnMovement") or not same(component:GetOwner(),p) then
        M.restore();return "Этот дрон пока не поддержан: нет проверенного компонента движения."
    end
    if journal and not same(journal.object,component) and not M.restore() then return "Не удалось восстановить прежний компонент." end
    if not journal then
        local original={}
        for _,key in ipairs({"MaxSpeed","Acceleration","Deceleration"}) do
            local v=get(component,key);if not finite(v) or v<=0 then return "Параметры дрона недоступны; изменений нет." end
            original[key]=v
        end
        if original.MaxSpeed>400/.036 then return "Исходная скорость выше поддерживаемого предела; изменений нет." end
        journal={object=component,original=original}
    end
    local multiplier=bounded(control.droneMultiplier,1,10,2)
    local seconds=bounded(control.droneRamp,.2,3,.75)
    local cap=Options.speed("drone",control.droneSpeed)/.036
    local target=math.max(journal.original.MaxSpeed,math.min(journal.original.MaxSpeed*multiplier,cap))
    local values={MaxSpeed=target,Acceleration=math.max(journal.original.Acceleration,target/seconds),
        Deceleration=math.max(journal.original.Deceleration,journal.original.Deceleration*multiplier)}
    for key,value in pairs(values) do if get(component,key)~=value then component[key]=value end end
    return string.format("Локальный предел: %.0f км/ч · расчётный разгон: %.2f с",target*.036,seconds)
end
local function vehicle(p,control,dt)
    local movement=p:GetMovementComponent()
    if not hasClass(movement,"ChaosVehicleMovementComponent") or not same(movement:GetOwner(),p) then
        return "Этот транспорт пока не поддержан: нужен компонент Chaos Vehicle."
    end
    local body=get(movement,"UpdatedComponent")
    if not hasClass(body,"PrimitiveComponent") or not same(body:GetOwner(),p) then return "Физический корпус транспорта недоступен." end
    if not body:IsSimulatingPhysics(FName("None")) then return "Корпус сейчас не симулирует физику; разгон не применяется." end
    local throttle,brake,gear=movement:GetThrottleInput(),movement:GetBrakeInput(),movement:GetCurrentGear()
    local handbrake=movement:GetHandbrakeInput()
    if not finite(throttle) or not finite(brake) or not finite(gear) or type(handbrake)~="boolean" then return "Не удалось прочитать газ и тормоз; разгон не применяется." end
    if brake>.01 or handbrake then return "Пауза: нажат тормоз." end
    if math.abs(throttle)<.05 or gear==0 then return "Готово: нажми газ и включи передачу." end
    if not dt then return "Ожидание игрового времени; разгон не применяется." end
    local v=body:GetPhysicsLinearVelocity(FName("None"))
    local forward=p:GetActorForwardVector()
    local sign=gear<0 and -1 or 1
    local target=Options.speed("vehicle",control.vehicleSpeed)/.036
    local multiplier=bounded(control.vehicleMultiplier,1,10,3)
    local delta=M.impulse(v,{X=forward.X*sign,Y=forward.Y*sign,Z=forward.Z*sign},target,800*multiplier,dt,math.abs(throttle))
    if delta then body:AddImpulse(delta,FName("None"),true) end
    return string.format("Локальная помощь разгону · предел %.0f км/ч%s",target*.036,gear<0 and " · задний ход" or "")
end
function M.update(pc,p,menuOpen,control,menu)
    -- Direct possession only. ViewTarget, attached passengers and owned remote actors are never used.
    local ok=valid(pc) and valid(p) and pc:IsLocalPlayerController() and same(pc.Pawn,p) and p:IsLocallyControlled() and same(pc:GetWorld(),p:GetWorld())
    if not ok then
        changePawn(control,menu);lastPawn=nil;text.vehicle="Нет управляемого транспорта.";text.drone="Нет управляемого ударного дрона.";return
    end
    if not same(lastPawn,p) then
        changePawn(control,menu);lastPawn=p;droneImpulses=0;lastDroneDelta=0
    end
    if fault then
        if not control.vehicleBoost and not control.droneBoost then
            M.restore();lastTime=nil;return
        end
        fault=nil
    end
    local now=gameTime(p);local dt=now and lastTime and math.max(0,math.min(.1,now-lastTime)) or nil;lastTime=now
    local selected=kind(p)
    text.vehicle="Сядь за руль поддерживаемого транспорта."
    text.drone=selected=="spectator" and "Дрон наблюдателя исключён." or selected=="unknownDrone" and "Этот тип дрона пока не поддержан." or "Переключись на ударный дрон."
    if menuOpen or get(p,"bIsBroken")==true then
        physicalRamp=0
        local restored=M.restore()
        if selected=="vehicle" then text.vehicle="Пауза: закрой меню; повреждённая техника не ускоряется." end
        if selected=="drone" then text.drone="Пауза: закрой меню; повреждённый дрон не ускоряется." end
        if not restored then text.drone="Восстановление параметров не завершено; повторю попытку." end
        return
    end
    if selected~="drone" or not control.droneBoost then
        physicalRamp=0
        if not M.restore() then text.drone="Повторное восстановление исходных параметров…";return end
    end
    if selected=="drone" then
        text.drone=control.droneBoost and drone(p,control,dt) or "Выключено. Ударный дрон обнаружен."
    elseif selected=="vehicle" then
        text.vehicle=control.vehicleBoost and vehicle(p,control,dt) or "Выключено. Транспорт обнаружен."
    end
    local v=p:GetVelocity()
    if finite(v.X) and finite(v.Y) and finite(v.Z) then
        local k=selected=="vehicle" and "vehicle" or selected=="drone" and "drone" or nil
        if k then text[k]=text[k]..string.format("\nСкорость: %.0f км/ч",math.sqrt(v.X^2+v.Y^2+v.Z^2)*.036) end
    end
end
function M.status() return text.vehicle,text.drone end
local reportSignature=nil
function M.report(root,pc,p,control,menuOpen)
    -- Read-only record: retain the attempted context even after a round ends.
    local function describe(o)
        if not valid(o) then return "<unavailable>" end
        local ok,n=pcall(function() return o:GetFullName() end)
        return ok and tostring(n) or "<unavailable>"
    end
    local function read(fn)
        local ok,v=pcall(fn)
        return ok and tostring(v) or "<unavailable>"
    end
    local function flat(s) return tostring(s):gsub("[\r\n]"," | ") end
    local vehicleStatus=text.vehicle:match("^[^\r\n]*")
    local droneStatus=text.drone:match("^[^\r\n]*")
    local lines={"pawn="..describe(p),"kind="..kind(p),
        "controller_pawn="..describe(get(pc,"Pawn")),
        "view_target="..read(function() return describe(pc:GetViewTarget()) end),
        "locally_controlled="..read(function() return p:IsLocallyControlled() end),
        "authority="..read(function() return p:HasAuthority() end),
        "menu="..tostring(menuOpen),"vehicle_enabled="..tostring(control.vehicleBoost==true),
        "drone_enabled="..tostring(control.droneBoost==true),
        "vehicle_status="..flat(vehicleStatus),"drone_status="..flat(droneStatus)}
    local signature=table.concat(lines,"\n")
    local f=io.open(root.."/data/vehicle-inspection.txt","wb")
    if f then
        f:write(signature.."\n")
        local floating=get(p,"FloatingPawnMovement")
        f:write("floating="..describe(floating).."\n")
        for _,key in ipairs({"MaxSpeed","Acceleration","Deceleration"}) do f:write(key.."="..read(function() return floating[key] end).."\n") end
        f:write("movement="..read(function() return describe(p:GetMovementComponent()) end).."\n")
        f:write("body="..describe(get(p,"Body")).."\nThrottle="..read(function() return p.Throttle end).."\nCurThrottle="..read(function() return p.CurThrottle end).."\nThrust="..read(function() return p.Thrust end).."\n")
        f:write("body_simulating="..read(function() return p.Body:IsSimulatingPhysics(FName("None")) end).."\n")
        f:write("drone_strength="..tostring(control.droneMultiplier or 2).."\ndrone_limit="..tostring(control.droneSpeed or 180).."\n")
        f:write("drone_steering="..tostring(control.droneSteering or 50).."\n")
        f:write("drone_impulses="..tostring(droneImpulses).."\nlast_drone_delta_kmh="..tostring(lastDroneDelta).."\n")
        f:close()
    end
    if signature~=reportSignature then
        local history=io.open(root.."/data/vehicle-events.txt","ab")
        if history then history:write(os.date("!%Y-%m-%dT%H:%M:%SZ").."\n"..signature.."\n\n");history:close();reportSignature=signature end
    end
end
return M
