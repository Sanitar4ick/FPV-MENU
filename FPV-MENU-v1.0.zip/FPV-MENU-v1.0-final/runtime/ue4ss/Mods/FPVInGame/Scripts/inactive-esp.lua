local M={};local lastSignature,lastSession=nil,nil
local function valid(o)local ok,v=pcall(function()return o and o:IsValid()end);return ok and v end
local function get(o,k)local ok,v=pcall(function()return o[k]end);if ok then return v end end
function M.inactive(o,drone)
    local health=get(o,"HealthComponent");local state=valid(health) and get(health,"DeathState")
    if type(state)=="number" and state>0 then return true end
    if drone then return get(o,"bIsBroken")==true or get(o,"bIsControlled")==false end
    return false
end
function M.update(bridge)
    local session=bridge.identity();if not session then lastSignature=nil;return end
    if session~=lastSession then lastSignature=nil;lastSession=session end
    local addresses,seen={},{}
    local function add(o)
        if not valid(o) then return end
        local address=o:GetAddress()
        if not seen[address] and #addresses<512 then seen[address]=true;addresses[#addresses+1]=string.format("%X",address) end
    end
    for _,entry in ipairs({{"BP_Character_MMC_C",false},{"BP_Drone_Base_C",true}}) do
        for _,o in ipairs(FindAllOf(entry[1]) or {}) do
            if valid(o) and M.inactive(o,entry[2]) then
                add(o);add(get(o,"Body"));add(get(o,"Mesh"))
                pcall(function()
                    local components=o:GetComponentsByClass(StaticFindObject("/Script/Engine.MeshComponent"))
                    components:ForEach(function(_,item)add(item:get())end)
                end)
            end
        end
    end
    table.sort(addresses);local signature=table.concat(addresses,",")
    -- Refresh even unchanged lists: the bridge expires stale colour overrides after two seconds.
    if signature~=lastSignature then
        if bridge.send("@inactive",signature) then lastSignature=signature end
    else bridge.send("@inactiveAlive","") end
end
return M
