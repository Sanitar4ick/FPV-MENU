local M={}
local function distance(a,b)return math.sqrt((a.X-b.X)^2+(a.Y-b.Y)^2+(a.Z-b.Z)^2)end
-- This is a local position observation, never proof of server acceptance.
function M.assess(origin,destination,current)
    local remaining=distance(current,destination)
    local planned=distance(origin,destination)
    local back=distance(current,origin)
    if planned>200 and back<=math.min(150,planned*.2) and remaining>=planned*.75 then
        return "returned",remaining
    end
    if remaining<=150 then return "near",remaining end
    return "moved",remaining
end
return M
