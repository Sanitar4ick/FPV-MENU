-- Read-only inventory of the local character's movement and granted abilities.
-- Does not activate abilities, invoke RPCs, or write gameplay properties.
local M={}
local captured={}
local function valid(o)
    local ok,v=pcall(function()
        if o==nil or not o:IsValid() then return false end
        return type(o:GetFullName())=="string"
    end)
    return ok and v
end
local function name(o)
    if not valid(o) then return "<unavailable>" end
    local ok,v=pcall(function() return o:GetFullName() end)
    return ok and v or "<unavailable>"
end
local function movement_related(s)
    s=s:lower()
    for _,word in ipairs({"speed","sprint","move","teleport","stamina","run","dash","dodge","slide","vault","jump","ladder"}) do
        if s:find(word,1,true) then return true end
    end
    return false
end
local function relevant(s) return movement_related(s) or s:lower():find("ability",1,true)~=nil end
local probeStarted=false
local function startDroneProbe(root,pc)
    if probeStarted or not valid(pc) then return end
    probeStarted=true
    local previous=_G.FPVDroneInputProbe
    if previous then previous.cancelled=true end
    local probe={count=0}
    _G.FPVDroneInputProbe=probe
    _G.FPVDroneInputProbeHistory=_G.FPVDroneInputProbeHistory or {}
    table.insert(_G.FPVDroneInputProbeHistory,probe)
    -- Bounded, read-only sampling of the actual possessed drone, not an arbitrary world actor.
    probe.callback=function()
        if probe.cancelled then return true end
        probe.count=probe.count+1
        local ok,err=pcall(function()
            if not valid(pc) then return end
            local p=pc.Pawn
            if not valid(p) then return end
            local cls=p:GetClass();local drone=false
            for _=1,16 do
                if not valid(cls) then break end
                if cls:GetFName():ToString()=="BP_Drone_FPV_C" then drone=true;break end
                cls=cls:GetSuperStruct()
            end
            if not drone then return end
            local lines={os.date("!%Y-%m-%dT%H:%M:%SZ"),"pawn="..name(p)}
            for _,key in ipairs({"Throttle","CurThrottle","QuantizedThrottle","Thrust","bIsBroken"}) do
                local read,v=pcall(function()return p[key]end)
                lines[#lines+1]=key.."="..(read and tostring(v) or "unavailable")
            end
            local v=p:GetVelocity()
            lines[#lines+1]=string.format("speed_kmh=%.2f",math.sqrt(v.X*v.X+v.Y*v.Y+v.Z*v.Z)*.036)
            local f=io.open(root.."/data/drone-input-probe.txt","ab")
            if f then f:write(table.concat(lines,"\n"),"\n\n");f:close() end
        end)
        if not ok then print("[FPVInGame] Drone input probe: "..tostring(err).."\n");return true end
        return probe.count>=600
    end
    probe.loop=LoopInGameThreadWithDelay(200,probe.callback)
end
local teamCaptured=false
local lifeCaptured=false
local function captureLife(root)
    if lifeCaptured then return end
    lifeCaptured=true
    local lines={"Life/controller state — read only",os.date("!%Y-%m-%dT%H:%M:%SZ")}
    local seen={}
    local function inspect(o,follow)
        if not valid(o) or seen[name(o)] then return end
        seen[name(o)]=true;lines[#lines+1]="\n"..name(o)
        local c=o:GetClass();local refs={}
        for _=1,12 do
            if not valid(c) then break end
            c:ForEachProperty(function(prop)
                local n=prop:GetFName():ToString();local l=n:lower()
                if l:find("health",1,true) or l:find("dead",1,true) or l:find("death",1,true) or l:find("broken",1,true) or l:find("controller",1,true) or l=="body" or l=="mesh" then
                    local ok,v=pcall(function()return o[n]end)
                    local value=ok and (valid(v) and name(v) or (type(v)=="number" or type(v)=="boolean") and tostring(v) or "<non-scalar>") or "<unavailable>"
                    lines[#lines+1]=string.format("0x%X %s = %s",prop:GetOffset_Internal(),n,value)
                    if follow and l:find("health",1,true) and valid(v) then refs[#refs+1]=v end
                end
            end)
            c=c:GetSuperStruct()
        end
        for _,v in ipairs(refs) do inspect(v,false) end
    end
    local ok,err=pcall(function()
        for _,class in ipairs({"BP_Character_MMC_C","BP_Kamikaze_C"}) do
            local count=0
            for _,o in ipairs(FindAllOf(class) or {}) do
                if valid(o) then inspect(o,true);count=count+1;if count>=24 then break end end
            end
        end
    end)
    if not ok then lines[#lines+1]=tostring(err) end
    local f=assert(io.open(root.."/data/life-inspection.txt","wb"));f:write(table.concat(lines,"\n"));f:close()
end
local function captureTeams(root,pc,pawn)
    if teamCaptured then return end
    teamCaptured=true
    local lines={"Player team layout — read only",os.date("!%Y-%m-%dT%H:%M:%SZ")}
    local seen={}
    local function inspect(o,title,follow)
        if not valid(o) or seen[name(o)] then return end
        seen[name(o)]=true;lines[#lines+1]="\n"..title..": "..name(o)
        local refs={};local c=o:GetClass()
        for _=1,12 do
            if not valid(c) then break end
            c:ForEachProperty(function(prop)
                local n=prop:GetFName():ToString();local lower=n:lower()
                if lower:find("team",1,true) or lower:find("playerstate",1,true) then
                    local ok,v=pcall(function()return o[n]end)
                    local value=ok and (valid(v) and name(v) or (type(v)=="number" or type(v)=="boolean") and tostring(v) or "<non-scalar>") or "<unavailable>"
                    lines[#lines+1]=string.format("  0x%X %s = %s",prop:GetOffset_Internal(),n,value)
                    if follow and valid(v) and lower:find("playerstate",1,true) then refs[#refs+1]={v,n} end
                end
            end)
            c=c:GetSuperStruct()
        end
        for _,ref in ipairs(refs) do inspect(ref[1],ref[2],false) end
    end
    local ok,err=pcall(function()
        inspect(pc,"Local controller",true);inspect(pawn,"Local pawn",true)
        local count=0
        for _,o in ipairs(FindAllOf("BP_Character_MMC_C") or {}) do
            if valid(o) then inspect(o,"Character sample",true);count=count+1;if count>=12 then break end end
        end
    end)
    if not ok then lines[#lines+1]="Partial report: "..tostring(err) end
    local f=assert(io.open(root.."/data/team-inspection.txt","wb"));f:write(table.concat(lines,"\n"),"\n");f:close()
end
local techCaptured=false
local function captureTech(root)
    if techCaptured then return end
    -- Inspect one existing kamikaze drone, read-only; never activate or control it.
    local target
    for _,o in ipairs(FindAllOf("BP_Kamikaze_C") or {}) do if valid(o) then target=o;break end end
    if not target then return end
    techCaptured=true
    local lines={"Kamikaze component inspection — READ ONLY",os.date("!%Y-%m-%dT%H:%M:%SZ")}
    local queue={{target,"Drone"}};local seen={}
    local function add(o,title)
        if not valid(o) then return end
        local key=name(o)
        if not seen[key] and #queue<10 then seen[key]=true;queue[#queue+1]={o,title} end
    end
    seen[name(target)]=true
    pcall(function() add(target:GetMovementComponent(),"Movement component") end)
    local i=1
    while i<=#queue do
        local o,title=queue[i][1],queue[i][2];i=i+1
        lines[#lines+1]="\n"..title..": "..name(o)
        local ok,err=pcall(function()
            local c=o:GetClass()
            for depth=1,8 do
                if not valid(c) then break end
                lines[#lines+1]="Class: "..name(c)
                c:ForEachProperty(function(prop)
                    local n=prop:GetFName():ToString()
                    if depth<=3 or movement_related(n) or n:lower():find("physics",1,true) then
                        local readable,v=pcall(function() return o[n] end)
                        local value="<unavailable>"
                        if readable then
                            if type(v)=="number" or type(v)=="boolean" or type(v)=="string" then value=tostring(v)
                            elseif valid(v) then
                                value=name(v)
                                if o==target and (n:lower():find("movement",1,true) or n=="Body" or n:lower():find("physics",1,true)) then add(v,n) end
                            else value="<"..type(v)..">" end
                        end
                        lines[#lines+1]="  "..n.." = "..value
                    end
                end)
                c=c:GetSuperStruct()
            end
        end)
        if not ok then lines[#lines+1]="Partial section: "..tostring(err) end
    end
    local f=assert(io.open(root.."/data/kamikaze-inspection.txt","wb"))
    f:write(table.concat(lines,"\n"),"\n");f:close()
    print("[FPVInGame] Read-only kamikaze component inspection saved.\n")
end
local function captureProtection(root,pc,pawn)
    if not valid(pawn) then return end
    local lines={"Protection inventory — read only",os.date("!%Y-%m-%dT%H:%M:%SZ"),"Authority="..tostring(pawn:HasAuthority())}
    local function relevantHealth(n)
        n=n:lower()
        for _,word in ipairs({"health","damage","death","dead","god","cheat","immun","invulner","armor","shield","hidden","visibility","effect","tag"}) do
            if n:find(word,1,true) then return true end
        end
        return false
    end
    local function get(o,k)local ok,v=pcall(function()return o[k]end);if ok then return v end end
    local function inspect(o,title,all)
        lines[#lines+1]="\n"..title.."="..name(o)
        if not valid(o) then return end
        local c=o:GetClass()
        for depth=1,10 do
            if not valid(c) then break end
            c:ForEachProperty(function(prop)
                local n=prop:GetFName():ToString()
                if relevantHealth(n) or (all and depth==1) then
                    local v=get(o,n)
                    local value=(type(v)=="number" or type(v)=="boolean") and tostring(v) or (valid(v) and name(v) or "<non-scalar>")
                    lines[#lines+1]="  "..n.."="..value
                    if n=="Health" or n=="MaxHealth" or n=="Armor" or n=="Shield" then
                        for _,key in ipairs({"BaseValue","CurrentValue"}) do
                            local scalar=get(v,key)
                            if type(scalar)=="number" then lines[#lines+1]="    "..key.."="..scalar end
                        end
                    end
                end
            end)
            c:ForEachFunction(function(fn)
                local n=fn:GetFName():ToString()
                if relevantHealth(n) or (all and depth==1) then
                    lines[#lines+1]="  "..name(fn).." flags="..string.format("0x%X",fn:GetFunctionFlags())
                    fn:ForEachProperty(function(prop)lines[#lines+1]="    "..prop:GetFullName()end)
                end
            end)
            c=c:GetSuperStruct()
        end
    end
    for _,entry in ipairs({{pawn,"Character",false},{get(pawn,"HealthSet"),"Health attributes",true},{get(pawn,"HealthComponent"),"Health component",true},{get(pawn,"AbilitySystemComponent"),"Ability system",false},{pc,"Controller",false},{get(pc,"CheatManager"),"Cheat manager",true}}) do
        local ok,e=pcall(inspect,entry[1],entry[2],entry[3]);if not ok then lines[#lines+1]="  Section failed: "..tostring(e) end
    end
    lines[#lines+1]="\nProtection tag counts (read only):"
    local asc=get(pawn,"AbilitySystemComponent")
    if valid(asc) then
        for _,tag in ipairs({"Gameplay.DamageImmunity","Cheat.GodMode","Cheat.UnlimitedHealth"}) do
            local ok,count=pcall(function()return asc:GetGameplayTagCount({TagName=FName(tag)})end)
            lines[#lines+1]=tag.."="..(ok and tostring(count) or "unavailable: "..tostring(count))
        end
    end
    lines[#lines+1]="\nTag helper signatures (not invoked):"
    for _,path in ipairs({"/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:AddLooseGameplayTags","/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:RemoveLooseGameplayTags","/Script/GameplayTags.BlueprintGameplayTagLibrary:MakeGameplayTagContainerFromTag"}) do
        local ok,e=pcall(function()
            local fn=StaticFindObject(path);lines[#lines+1]=path.." available="..tostring(valid(fn))
            if valid(fn) then fn:ForEachProperty(function(prop)lines[#lines+1]="  "..prop:GetFullName()end) end
        end)
        if not ok then lines[#lines+1]="  Signature unavailable: "..tostring(e) end
    end
    -- Metadata and existing class defaults only. No effect creation/application,
    -- no tag-container conversion, no cheat-manager commands.
    lines[#lines+1]="\nProtection paths v4 (read-only class defaults):"
    for _,path in ipairs({"/Script/FPVKamikazeDrone.Default__FPVCheatManager","/Script/FPVKamikazeDrone.Default__FPVHealthSet","/Script/FPVKamikazeDrone.Default__FPVDamageExecution"}) do
        local ok,e=pcall(function()inspect(StaticFindObject(path),path,true)end)
        if not ok then lines[#lines+1]="  Metadata unavailable: "..tostring(e) end
    end
    lines[#lines+1]="\nLoaded gameplay effect defaults:"
    local effectOk,effectError=pcall(function()
        local total,detailed=0,0
        -- FindAllOf excludes class defaults, so it cannot serve this inventory.
        -- LuaMod.cpp: arguments 4/5 are required/banned flags respectively.
        -- The public API documentation reverses these two descriptions.
        local defaults=FindObjects(256,"GameplayEffect",nil,EObjectFlags.RF_ClassDefaultObject,EObjectFlags.RF_NoFlags,false)
        local base=StaticFindObject("/Script/GameplayAbilities.Default__GameplayEffect")
        lines[#lines+1]="control_base_default="..name(base)
        local baseFound=false
        for _,o in ipairs(defaults or {}) do if valid(o) and name(o)==name(base) then baseFound=true end end
        lines[#lines+1]="control_base_in_query="..tostring(baseFound)
        if valid(base) and not baseFound then
            lines[#lines+1]="WARNING: known class default missing; inventory cannot establish absence of effects"
        end
        for _,effect in ipairs(defaults or {}) do
            if valid(effect) then
                local full=name(effect)
                if full:find("Default__",1,true) then
                    total=total+1
                    lines[#lines+1]=full
                    local lower=full:lower()
                    local short=effect:GetFName():ToString():lower()
                    if detailed<24 and (relevantHealth(short) or lower:find("spawn",1,true) or lower:find("protect",1,true)) then
                        detailed=detailed+1
                        local ok,e=pcall(inspect,effect,"Effect candidate",true)
                        if not ok then lines[#lines+1]="  Effect metadata unavailable: "..tostring(e) end
                    end
                    if total>=256 then lines[#lines+1]="  Inventory capped at 256 defaults";break end
                end
            end
        end
        lines[#lines+1]="defaults_listed="..total
    end)
    if not effectOk then lines[#lines+1]="  Effect inventory unavailable: "..tostring(effectError) end
    local f=assert(io.open(root.."/data/protection-inspection.txt","wb"));f:write(table.concat(lines,"\n"),"\n");f:close()
    print("[FPVInGame] Read-only protection inventory saved.\n")
end
function M.capture(root,pc,pawn,movement)
    local protectionOk,protectionError=pcall(captureProtection,root,pc,pawn)
    if not protectionOk then print("[FPVInGame] Protection inspection: "..tostring(protectionError).."\n") end
    local lifeOk,lifeErr=pcall(captureLife,root)
    if not lifeOk then print("[FPVInGame] Life inspection: "..tostring(lifeErr).."\n") end
    startDroneProbe(root,pc)
    local teamOk,teamError=pcall(captureTeams,root,pc,pawn)
    if not teamOk then print("[FPVInGame] Team inspection: "..tostring(teamError).."\n") end
    local techOk,techError=pcall(captureTech,root)
    if not techOk then print("[FPVInGame] Kamikaze inspection: "..tostring(techError).."\n") end
    if not valid(pawn) or not valid(movement) then return end
    local class=pawn:GetClass()
    local key=name(class)
    if captured[key] then return end
    captured[key]=true -- One attempt per character class; no repeated reflection on failure.
    local lines={"FPV movement inspection — read-only",os.date("!%Y-%m-%dT%H:%M:%SZ"),
        "Local character class: "..key,"Authority: "..tostring(pawn:HasAuthority())}
    local function line(s) lines[#lines+1]=s end
    local function properties(object,title)
        line("\n"..title..": "..name(object))
        if not valid(object) then return end
        local c=object:GetClass()
        for depth=1,10 do
            if not valid(c) then break end
            line("Class: "..name(c))
            c:ForEachProperty(function(prop)
                local n=prop:GetFName():ToString()
                if relevant(n) or (title=="Movement-related ability" and depth<=3) then
                    local ok,v=pcall(function() return object[n] end)
                    local text="<unreadable>"
                    if ok then
                        if type(v)=="number" or type(v)=="boolean" then text=tostring(v)
                        elseif valid(v) then text=name(v)
                        else text="<"..type(v)..">" end
                    end
                    line("  Property "..n.." = "..text)
                end
            end)
            c:ForEachFunction(function(fn)
                local n=fn:GetFName():ToString()
                if depth<=2 or relevant(n) then
                    local ok,flags=pcall(function() return fn:GetFunctionFlags() end)
                    line("  Function "..name(fn).." flags="..(ok and string.format("0x%X",flags) or "unknown"))
                end
            end)
            c=c:GetSuperStruct()
        end
    end
    local function section(object,title)
        local ok,err=pcall(properties,object,title)
        if not ok then line("Section unavailable: "..tostring(err)) end
    end
    local ok,err=pcall(function()
        section(pawn,"Character")
        section(movement,"Movement")
        section(pc,"Local controller")
        line("\nPosition-related function signatures (read only):")
        for _,fnName in ipairs({"ServerSetRootTransform","CalculateRootTransform","UpdateRootTransform","ServerEndRagdoll","ClientExitVehicle"}) do
            local path="/Game/Characters/BP_Character_Base.BP_Character_Base_C:"..fnName
            local fn=StaticFindObject(path)
            if valid(fn) then
                line(name(fn))
                fn:ForEachProperty(function(prop)
                    local ok,description=pcall(function() return prop:GetFullName() end)
                    line("  "..(ok and description or prop:GetFName():ToString()))
                end)
            end
        end
        local asc=pawn.AbilitySystemComponent
        section(asc,"Local ability system")
        if valid(asc) then
            line("\nGranted abilities:")
            local arrayOk,arrayErr=pcall(function()
                local items=asc.ActivatableAbilities.Items
                items:ForEach(function(index,element)
                    if index>128 then line("  <list capped>");return true end
                    local spec=element:get()
                    line("  Ability "..name(spec.Ability))
                    if valid(spec.Ability) and movement_related(name(spec.Ability)) then
                        section(spec.Ability,"Movement-related ability")
                    end
                end)
            end)
            if not arrayOk then line("  Unavailable: "..tostring(arrayErr)) end
        end
    end)
    if not ok then line("Partial report: "..tostring(err)) end
    local path=root.."/data/movement-inspection-"..os.date("!%Y%m%d-%H%M%S")..".txt"
    local f,e=io.open(path,"w")
    if not f then error(e) end
    f:write(table.concat(lines,"\n"),"\n");f:close()
    print("[FPVInGame] Read-only movement inspection saved: "..path.."\n")
end
return M
